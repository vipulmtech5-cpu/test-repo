# Daily Job Hunt Automation

Finds roles matching Vipul Mayekar's profile, ranks them, and emails the **top 50**
as an Excel sheet to `vipulm.tech5@gmail.com` every morning.

**Target role families:**
1. Senior Platform Engineer
2. Senior DevOps Engineer
3. Cloud / Platform SRE
4. Senior Cloud Engineer

## Setup on your personal Mac

```bash
unzip job_hunt_portable_<date>.zip
cd job_hunt
bash bootstrap.sh             # installs deps, checks connectivity, dry run
# add the Gmail app password to .env, then:
python3 daily_job_hunt.py --seed --show-all    # sends a real email
bash setup_schedule.sh                        # schedule daily at 08:30
```

`bootstrap.sh` runs a connectivity check and tells you whether the network you
are on is filtering job boards.

## Moving this folder to another machine

```bash
bash package_for_transfer.sh
```

Produces `../job_hunt_portable_<date>.zip`, deliberately excluding `.env`
(your Gmail password), `reports/`, logs, `seen_jobs.json` and `__pycache__`.
Only `requests` and `openpyxl` are needed on the target machine, and
`bootstrap.sh` installs both.

## Files

| File | Purpose |
|---|---|
| `daily_job_hunt.py` | Entry point. Orchestrates fetch → filter → score → Excel → email |
| `config.py` | All tunables: titles, skill weights, salary band, sources, email |
| `matcher.py` | Scoring engine (0-100), role-family tagging, "why you fit" reasoning |
| `sources.py` | Connectors: Greenhouse, Lever, Ashby, RemoteOK, Adzuna, Jooble, Google Jobs |
| `report.py` | Excel builder + SMTP mailer |
| `seed_jobs.py` | Curated shortlist of 60 live roles from the Sep 2026 search |
| `bootstrap.sh` | One-shot setup on a fresh Mac |
| `package_for_transfer.sh` | Builds the portable zip |
| `setup_schedule.sh` | macOS LaunchAgent installer |

## Scoring model (100 points)

| Component | Points | What it measures |
|---|---|---|
| Skills | 55 | Weighted overlap with AWS, EKS, Terraform, Jenkins, Airflow, observability, plus SRE competencies (SLO, reliability, incident response, HA, DR) |
| Title | 15 | Alignment with the four target role families |
| Seniority | 10 | Years-required window vs 3.3 yrs actual. 3-4 yrs scores best, 6+ penalised |
| Location | 10 | Mumbai cluster and remote score highest, then other metros |
| Domain | 10 | Fintech, banking, lending, data-platform, multi-tenant SaaS signals |

Penalties apply when a JD leans on Azure, GCP, VMware or .NET.

**Output volume:** roles scoring 80+ are ranked and the best 50 are reported
(`TOP_N_RESULTS` in `config.py`). If fewer than 25 clear the bar on a quiet day,
the threshold steps down in 5-point increments to a floor of 70 so the sheet
stays useful rather than arriving near-empty. `seen_jobs.json` prevents the same
role being emailed twice.

## Important: corporate network blocks job boards

The IDFC FIRST network runs a Netskope web proxy that returns HTTP 403 for URL
category "HR", which covers Greenhouse, Lever, Adzuna, RemoteOK, SmartRecruiters
and most job boards. Verified on 06 Sep 2026:

- Blocked: `boards-api.greenhouse.io`, `api.lever.co`, `remoteok.com`,
  `api.adzuna.com`, `api.smartrecruiters.com`, `jobicy.com`, `himalayas.app`
- Reachable: `api.ashbyhq.com`, `apply.workable.com`, `serpapi.com`

The script detects the block explicitly and logs
`BLOCKED BY CORPORATE PROXY: <host>` rather than silently reporting zero
matches. **Schedule this on your personal Mac or home network** for full
coverage. Running it on the bank network will only reach Ashby, Workable and
SerpApi.

## API keys

All optional; the script runs without them but with reduced coverage.
Highest value first:

1. **SerpApi** (100 free searches/month) — this is the LinkedIn + Indeed +
   Naukri channel via Google Jobs. Set `SERPAPI_KEY`.
2. **Adzuna** (free) — Indeed and career-page coverage for India.
3. **Jooble** (free on request) — extra aggregator breadth.

LinkedIn and Indeed have no public job-search API and their terms prohibit
scraping, so Google Jobs is the supported route to that inventory.

## Command reference

```bash
python3 daily_job_hunt.py                 # live sources only
python3 daily_job_hunt.py --seed          # live sources + curated shortlist
python3 daily_job_hunt.py --seed-only     # score the shortlist, no network
python3 daily_job_hunt.py --no-email      # build the sheet, skip sending
python3 daily_job_hunt.py --show-all      # re-include roles already emailed
python3 daily_job_hunt.py --top 25        # report 25 instead of 50
python3 daily_job_hunt.py --min-score 75  # fixed bar, disables auto-relax
```

## Tuning

Add companies you want tracked to `GREENHOUSE_BOARDS`, `LEVER_COMPANIES` or
`ASHBY_ORGS` in `config.py`. The board token is the last path segment of the
company's careers URL, e.g. `boards.greenhouse.io/amtechsoftware` →
`amtechsoftware`.

To bias the ranking toward a skill you want to be hired for, raise its weight in
`SKILL_WEIGHTS`.
