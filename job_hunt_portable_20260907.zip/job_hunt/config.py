# -*- coding: utf-8 -*-
"""
Central configuration for the daily job-hunt automation.

Everything that is likely to change (target titles, skills, salary band,
company boards to poll, email settings) lives here so the rest of the code
stays untouched.
"""
import os

# ----------------------------------------------------------------------------
# CANDIDATE PROFILE
# ----------------------------------------------------------------------------
CANDIDATE = {
    "name": "Vipul Mayekar",
    "current_title": "Senior Cloud DevOps Engineer",
    "current_company": "IDFC FIRST BANK",
    "years_experience": 3.3,
    "base_location": "Mumbai, India",
    "email": "vipulm.tech5@gmail.com",
    "phone": "+919820291063",
}

# ----------------------------------------------------------------------------
# TARGET ROLES
# Four role families, in priority order:
#   1. Senior Platform Engineer      2. Senior DevOps Engineer
#   3. Cloud / Platform SRE          4. Senior Cloud Engineer
# ----------------------------------------------------------------------------
TARGET_TITLE_PATTERNS = [
    r"\bdevops\b",
    r"\bdevsecops\b",
    # Cloud / Platform SRE family
    r"\bsite reliability\b|\bservice reliability\b|\bsre\b",
    r"\breliability engineer\b",
    r"\bcloud sre\b|\bplatform sre\b|\bsre platform\b",
    r"\bproduction engineer\b",
    # Platform engineering family
    r"\bplatform engineer\b|\bplatform engineering\b",
    r"\bplatform infrastructure\b|\bplatform automation\b",
    r"\bplatform developer\b|\bplatform software engineer\b",
    # Cloud engineering family
    r"\bcloud engineer\b|\bcloud infrastructure\b|\bcloud platform\b",
    r"\bcloud devops\b|\bcloud operations\b",
    r"\binfrastructure engineer\b|\binfrastructure platform\b",
    r"\bkubernetes engineer\b|\bkubernetes sre\b",
    r"\bsystems engineer\b",
    r"\bautomation engineer\b",
]

# Role-family labels for reporting, checked in order (first hit wins).
# Order matters: match on the role NOUN, not on incidental words. A title like
# "Senior DevOps Engineer (Big Data Platform)" is a DevOps role that happens to
# mention a platform, so DevOps must be tested before the platform family.
ROLE_FAMILIES = [
    ("Cloud / Platform SRE",
     r"\bsre\b|\bsite reliability\b|\bservice reliability\b|"
     r"\breliability engineer\b|\bproduction engineer\b"),
    ("Senior DevOps Engineer",
     r"\bdevops\b|\bdevsecops\b"),
    ("Senior Platform Engineer",
     r"\bplatform engineer\b|\bplatform engineering\b|\bplatform automation\b|"
     r"\bplatform software\b|\bplatform developer\b|\bplatform infrastructure\b"),
    ("Senior Cloud Engineer",
     r"\bcloud\b|\binfrastructure\b|\bkubernetes\b|\bsystems engineer\b"),
]

# Titles to reject outright (seniority or discipline mismatch).
EXCLUDE_TITLE_PATTERNS = [
    r"\bintern\b|\binternship\b|\btrainee\b|\bfresher\b",
    r"\bmanager\b|\bdirector\b|\bhead of\b",
    r"\bprincipal\b|\barchitect\b|\bdistinguished\b|\bstaff\b",
    r"\bsales\b|\bpre-?sales\b|\bsupport engineer\b|\btrainer\b|\brecruiter\b",
    r"\bdata scientist\b|\bfrontend\b|\bandroid\b|\bios\b|\bqa\b|\btest engineer\b",
]

# In banks and financial services, VP / AVP / Senior Associate are
# individual-contributor pay grades rather than people-management titles.
# A posting carrying one of these is kept as long as it is clearly an
# engineering IC role (i.e. the title also contains "engineer").
BANK_GRADE_PATTERNS = [
    r"\bvp\b", r"\bavp\b", r"\bvice president\b",
    r"\bsenior associate\b", r"\bassociate\b", r"\bsr\.? assoc\b",
]

# ----------------------------------------------------------------------------
# SKILL WEIGHTS  -> drive the match score
# Weight reflects how central the skill is to Vipul's proven track record.
# ----------------------------------------------------------------------------
SKILL_WEIGHTS = {
    # Core strengths (deep, demonstrable, quantified on the CV)
    "aws": 10,
    "kubernetes": 10,
    "eks": 9,
    "terraform": 9,
    "docker": 8,
    "jenkins": 8,
    "ci/cd": 8,
    "helm": 6,
    "ecs": 6,
    "fargate": 5,
    "karpenter": 5,
    "keda": 5,
    "prometheus": 6,
    "grafana": 6,
    "elk": 5,
    "opentelemetry": 5,
    "python": 7,
    "bash": 5,
    "linux": 6,
    "airflow": 6,
    "iam": 5,
    "vpc": 5,
    "lambda": 5,
    "cloudformation": 4,
    "nginx": 4,
    "cost optimization": 6,
    "finops": 5,
    "observability": 6,
    "autoscaling": 5,
    "emr": 4,
    "spark": 3,
    "groovy": 3,
    "postgresql": 3,
    "mysql": 3,
    # Adjacent / learnable (present in market, partial on CV)
    "argocd": 4,
    "gitops": 4,
    "github actions": 4,
    "gitlab": 3,
    "service mesh": 3,
    "istio": 3,
    "vault": 3,
    "ansible": 3,
    "kafka": 3,
    "datadog": 3,
    # SRE-specific competencies. Weighted meaningfully because Cloud/Platform
    # SRE is now a first-class target and the CV evidences most of these
    # (centralized logging framework, HA platforms, on-call ownership).
    "sre": 6,
    "slo": 5,
    "incident": 5,
    "reliability": 6,
    "high availability": 5,
    "disaster recovery": 4,
    "capacity planning": 4,
    "runbook": 3,
    "chaos": 2,
    "distributed tracing": 4,
    # Off-stack: presence pulls the score down (see NEGATIVE_SKILLS)
}

# Skills that signal a different stack. Each hit applies a small penalty.
NEGATIVE_SKILLS = {
    "azure": 4,
    "gcp": 3,
    "google cloud": 3,
    "openshift": 2,
    "vmware": 3,
    "windows server": 3,
    "powershell": 2,
    "mainframe": 5,
    "salesforce": 4,
    ".net": 3,
}

# ----------------------------------------------------------------------------
# EXPERIENCE + COMPENSATION FILTERS
# ----------------------------------------------------------------------------
YEARS_MIN_ACCEPTABLE = 0      # role asking for fewer years than this -> junior
YEARS_MAX_ACCEPTABLE = 6      # role asking for more than this -> stretch
EXPECTED_CTC_MIN_INR = 2_500_000
EXPECTED_CTC_MAX_INR = 3_000_000

# Locations we care about, in preference order. "remote" always qualifies.
PREFERRED_LOCATIONS = [
    "mumbai", "navi mumbai", "thane", "remote", "anywhere",
    "pune", "bengaluru", "bangalore", "hyderabad", "gurugram",
    "gurgaon", "noida", "delhi", "chennai", "india",
]

# Only surface roles at or above this score (out of 100).
MIN_MATCH_SCORE = 80

# Report the best N matches. Ranked by score, so this keeps the top slice.
TOP_N_RESULTS = 50

# If fewer than this many roles clear MIN_MATCH_SCORE, the threshold is
# relaxed in steps (down to RELAX_FLOOR) so the sheet stays useful on quiet
# days rather than arriving near-empty.
RELAX_IF_FEWER_THAN = 25
RELAX_FLOOR = 70

# Drop postings older than this many days.
MAX_POSTING_AGE_DAYS = 21

# ----------------------------------------------------------------------------
# SOURCES
# ----------------------------------------------------------------------------
# Greenhouse board tokens. Find via: company careers page -> boards.greenhouse.io/<token>
GREENHOUSE_BOARDS = [
    "amtechsoftware", "kong", "postman", "hasura", "chargebee",
    "browserstack", "clevertap", "innovaccer", "gupshup", "mindtickle",
    "whatfix", "harness", "sprinklr", "freshworks", "airbase",
    "juspay", "m2p", "signzy", "netradyne", "observeai",
]

# Lever company slugs: jobs.lever.co/<slug>
LEVER_COMPANIES = [
    "zeta", "cred", "razorpay", "groww", "slice", "jupiter",
    "dream11", "meesho", "swiggy", "upstox", "smallcase",
    "atlan", "hevodata", "sarvam", "kredx",
]

# Ashby orgs: jobs.ashbyhq.com/<slug>
ASHBY_ORGS = [
    "zluri", "spotdraft", "toplyne", "nirvana", "fleetworks",
]

# Recruitee / Workable / SmartRecruiters can be added the same way later.

REMOTEOK_ENABLED = True

# Optional keyed aggregators. These are what give LinkedIn / Indeed coverage.
# Set the env vars and they switch on automatically; leave unset to skip.
ADZUNA_APP_ID = os.getenv("ADZUNA_APP_ID", "")
ADZUNA_APP_KEY = os.getenv("ADZUNA_APP_KEY", "")
JOOBLE_API_KEY = os.getenv("JOOBLE_API_KEY", "")
SERPAPI_KEY = os.getenv("SERPAPI_KEY", "")   # Google Jobs -> LinkedIn/Indeed/Naukri

ADZUNA_QUERIES = [
    "senior devops engineer", "senior cloud engineer",
    "senior platform engineer", "site reliability engineer kubernetes",
]
ADZUNA_LOCATIONS = ["Mumbai", "Pune", "Bengaluru", "Hyderabad", "Gurgaon"]

SERPAPI_QUERIES = [
    "Senior DevOps Engineer AWS Kubernetes Mumbai",
    "Senior Cloud Engineer AWS EKS Terraform India",
    "Senior Platform Engineer Kubernetes Terraform India",
    "Site Reliability Engineer AWS EKS India remote",
]

# ----------------------------------------------------------------------------
# EMAIL
# ----------------------------------------------------------------------------
EMAIL = {
    "to": "vipulm.tech5@gmail.com",
    "from": os.getenv("JOBHUNT_SMTP_USER", "vipulm.tech5@gmail.com"),
    "smtp_host": os.getenv("JOBHUNT_SMTP_HOST", "smtp.gmail.com"),
    "smtp_port": int(os.getenv("JOBHUNT_SMTP_PORT", "587")),
    "smtp_user": os.getenv("JOBHUNT_SMTP_USER", "vipulm.tech5@gmail.com"),
    # Gmail App Password (16 chars, no spaces). NEVER hardcode it here.
    "smtp_password": os.getenv("JOBHUNT_SMTP_PASSWORD", ""),
}

# ----------------------------------------------------------------------------
# PATHS
# ----------------------------------------------------------------------------
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
OUTPUT_DIR = os.path.join(BASE_DIR, "reports")
STATE_DB = os.path.join(BASE_DIR, "seen_jobs.json")
LOG_FILE = os.path.join(BASE_DIR, "job_hunt.log")

HTTP_TIMEOUT = 25
USER_AGENT = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) job-hunt-bot/1.0"
