#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Daily job-hunt automation for Vipul Mayekar.

Pipeline:
    fetch (multi-source) -> title filter -> score -> threshold + dedupe
    -> Excel -> email to vipulm.tech5@gmail.com

Usage:
    python3 daily_job_hunt.py                # full run, sends email
    python3 daily_job_hunt.py --no-email     # build the sheet only
    python3 daily_job_hunt.py --show-all     # ignore the "already seen" filter
    python3 daily_job_hunt.py --min-score 75 # loosen the bar for one run
"""
import argparse
import datetime as dt
import hashlib
import json
import logging
import os
import re
import sys

from config import (
    LOG_FILE,
    MAX_POSTING_AGE_DAYS,
    MIN_MATCH_SCORE,
    OUTPUT_DIR,
    PREFERRED_LOCATIONS,
    RELAX_FLOOR,
    RELAX_IF_FEWER_THAN,
    STATE_DB,
    TOP_N_RESULTS,
)
from matcher import score_job, title_is_relevant
from report import build_workbook, output_path, send_email
from sources import fetch_all, find_hr_contact


def setup_logging(verbose=False):
    os.makedirs(os.path.dirname(LOG_FILE) or ".", exist_ok=True)
    logging.basicConfig(
        level=logging.DEBUG if verbose else logging.INFO,
        format="%(asctime)s  %(levelname)-7s %(name)-10s %(message)s",
        handlers=[logging.FileHandler(LOG_FILE), logging.StreamHandler(sys.stdout)],
    )
    return logging.getLogger("jobhunt")


def job_id(job):
    key = f"{job.get('company','').lower()}|{job.get('title','').lower()}|{job.get('url','')}"
    return hashlib.sha1(key.encode("utf-8")).hexdigest()[:16]


def load_state():
    if not os.path.exists(STATE_DB):
        return {}
    try:
        with open(STATE_DB, "r", encoding="utf-8") as fh:
            return json.load(fh)
    except (json.JSONDecodeError, OSError):
        return {}


def save_state(state):
    cutoff = (dt.date.today() - dt.timedelta(days=90)).isoformat()
    pruned = {k: v for k, v in state.items() if v >= cutoff}
    with open(STATE_DB, "w", encoding="utf-8") as fh:
        json.dump(pruned, fh, indent=0)


def location_ok(job):
    blob = f"{job.get('location','')} {job.get('title','')}".lower()
    if any(city in blob for city in PREFERRED_LOCATIONS):
        return True
    # Remote-worldwide listings often carry no country token.
    return "remote" in blob or "anywhere" in blob


def fresh_enough(job):
    posted = job.get("posted_at")
    if not posted:
        rel = (job.get("posted_relative") or "").lower()
        m = re.search(r"(\d+)\s*(day|hour|minute)", rel)
        if m and m.group(2) == "day":
            return int(m.group(1)) <= MAX_POSTING_AGE_DAYS
        if "month" in rel:
            return False
        return True   # unknown age -> keep, scoring still applies
    try:
        d = dt.datetime.strptime(posted, "%Y-%m-%d").date()
    except ValueError:
        return True
    return (dt.date.today() - d).days <= MAX_POSTING_AGE_DAYS


def dedupe(jobs):
    seen, out = set(), []
    for j in jobs:
        key = (j.get("company", "").lower().strip(), j.get("title", "").lower().strip())
        if key in seen:
            continue
        seen.add(key)
        out.append(j)
    return out


def run(args):
    log = setup_logging(args.verbose)
    log.info("=" * 68)
    log.info("Daily job hunt starting")

    raw = []
    if not args.seed_only:
        raw.extend(fetch_all())
    if args.seed or args.seed_only:
        from seed_jobs import SEED_JOBS
        raw.extend(SEED_JOBS)
        log.info("included %d curated seed roles", len(SEED_JOBS))
    log.info("fetched %d raw postings", len(raw))

    stage = [j for j in raw if j.get("url") and title_is_relevant(j.get("title", ""))]
    log.info("%d survive the title filter", len(stage))

    stage = [j for j in stage if location_ok(j)]
    log.info("%d survive the location filter", len(stage))

    stage = [j for j in stage if fresh_enough(j)]
    log.info("%d survive the freshness filter (<= %dd)", len(stage), MAX_POSTING_AGE_DAYS)

    for j in stage:
        score_job(j)
        if not j.get("hr_contact"):
            j["hr_contact"] = find_hr_contact(j)

    stage = dedupe(stage)

    state = load_state()
    if not args.show_all:
        before = len(stage)
        stage = [j for j in stage if job_id(j) not in state]
        log.info("%d are new (%d already reported previously)", len(stage), before - len(stage))

    stage.sort(key=lambda j: (-j["match_score"], j.get("company", "")))

    # Apply the match bar. If the day is thin, step the bar down so the sheet
    # still carries useful volume instead of arriving nearly empty.
    top_n = args.top if args.top is not None else TOP_N_RESULTS
    threshold = args.min_score if args.min_score is not None else MIN_MATCH_SCORE
    matches = [j for j in stage if j["match_score"] >= threshold]
    log.info("%d clear the %d%% match bar", len(matches), threshold)

    if args.min_score is None:
        while len(matches) < min(RELAX_IF_FEWER_THAN, top_n) and threshold > RELAX_FLOOR:
            threshold -= 5
            matches = [j for j in stage if j["match_score"] >= threshold]
            log.info("thin results, relaxed bar to %d%% -> %d roles", threshold, len(matches))

    if len(matches) > top_n:
        log.info("trimming %d -> top %d by score", len(matches), top_n)
        matches = matches[:top_n]

    if matches:
        log.info("reporting %d roles, scores %.1f down to %.1f",
                 len(matches), matches[0]["match_score"], matches[-1]["match_score"])

    path = output_path()
    build_workbook(matches, path)
    log.info("workbook written: %s", path)

    if matches and not args.no_email:
        try:
            send_email(path, matches)
        except Exception as exc:
            log.error("email failed: %s", exc)
    elif not matches:
        log.info("nothing new today - no email sent")

    today = dt.date.today().isoformat()
    for j in matches:
        state[job_id(j)] = today
    save_state(state)

    log.info("done. %d matches.", len(matches))
    return matches


def main():
    p = argparse.ArgumentParser(description="Daily job matcher + emailer")
    p.add_argument("--no-email", action="store_true", help="build the sheet, skip sending")
    p.add_argument("--show-all", action="store_true", help="ignore the already-seen filter")
    p.add_argument("--min-score", type=int, default=None,
                   help="override the match threshold (disables auto-relax)")
    p.add_argument("--top", type=int, default=None,
                   help=f"how many roles to report (default {TOP_N_RESULTS})")
    p.add_argument("--seed", action="store_true",
                   help="also include the curated shortlist in seed_jobs.py")
    p.add_argument("--seed-only", action="store_true",
                   help="score only the curated shortlist (no network calls)")
    p.add_argument("--verbose", action="store_true")
    args = p.parse_args()

    os.makedirs(OUTPUT_DIR, exist_ok=True)
    matches = run(args)

    if matches:
        print(f"\nTop {len(matches)} matches:")
        for i, j in enumerate(matches, start=1):
            print(f"  {i:>3}. {j['match_score']:>5}  {j['title'][:46]:<46} "
                  f"{j['company'][:20]:<20} {(j.get('location') or 'n/a')[:22]:<22} "
                  f"{j.get('role_family','')}")


if __name__ == "__main__":
    main()
