# -*- coding: utf-8 -*-
"""Excel report builder + SMTP mailer for the daily job digest."""
import datetime as dt
import logging
import os
import smtplib
from email.message import EmailMessage

from openpyxl import Workbook
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter
from openpyxl.worksheet.table import Table, TableStyleInfo

from config import EMAIL, OUTPUT_DIR

log = logging.getLogger("report")

COLUMNS = [
    ("#", 5),
    ("Job Title", 38),
    ("Company Name", 24),
    ("Location / Remote Status", 26),
    ("Direct Link", 12),
    ("HR Contact", 26),
    ("Match Score", 12),
    ("Match Reason", 88),
    ("Role Family", 24),
    ("Matched Skills", 40),
    ("Posted", 13),
    ("Source", 26),
    ("Salary (if listed)", 22),
]

LINK_COL = 5      # 1-indexed position of "Direct Link"
SCORE_COL = 7     # 1-indexed position of "Match Score"
WRAP_COLS = (2, 4, 8, 9, 10)

HEADER_FILL = PatternFill("solid", fgColor="102A43")
HEADER_FONT = Font(color="FFFFFF", bold=True, size=11)
BAND_HIGH = PatternFill("solid", fgColor="D6EFD8")   # 90+
BAND_MID = PatternFill("solid", fgColor="FFF4CE")    # 85-89
LINK_FONT = Font(color="1F4E79", underline="single")


def build_workbook(jobs, path):
    wb = Workbook()
    ws = wb.active
    ws.title = "Matches"

    for idx, (name, width) in enumerate(COLUMNS, start=1):
        cell = ws.cell(row=1, column=idx, value=name)
        cell.fill = HEADER_FILL
        cell.font = HEADER_FONT
        cell.alignment = Alignment(vertical="center", horizontal="center", wrap_text=True)
        ws.column_dimensions[get_column_letter(idx)].width = width
    ws.row_dimensions[1].height = 28

    for r, job in enumerate(jobs, start=2):
        score = job.get("match_score", 0)
        values = [
            r - 1,
            job.get("title", ""),
            job.get("company", ""),
            job.get("location", "") or "Not specified",
            job.get("url", ""),
            job.get("hr_contact", ""),
            score,
            job.get("match_reason", ""),
            job.get("role_family", ""),
            job.get("matched_skills", ""),
            job.get("posted_at", "") or job.get("posted_relative", ""),
            job.get("source", ""),
            job.get("salary", ""),
        ]
        for c, value in enumerate(values, start=1):
            cell = ws.cell(row=r, column=c, value=value)
            cell.alignment = Alignment(vertical="top", wrap_text=(c in WRAP_COLS))
            if c == LINK_COL and value:
                cell.hyperlink = value
                cell.value = "Apply"
                cell.font = LINK_FONT
                cell.alignment = Alignment(horizontal="center", vertical="top")
            if c in (1, SCORE_COL):
                cell.alignment = Alignment(horizontal="center", vertical="top")
                if c == SCORE_COL:
                    cell.font = Font(bold=True)
        if score >= 90:
            for c in range(1, len(COLUMNS) + 1):
                ws.cell(row=r, column=c).fill = BAND_HIGH
        elif score >= 85:
            for c in range(1, len(COLUMNS) + 1):
                ws.cell(row=r, column=c).fill = BAND_MID

    if jobs:
        ref = f"A1:{get_column_letter(len(COLUMNS))}{len(jobs) + 1}"
        table = Table(displayName="Matches", ref=ref)
        table.tableStyleInfo = TableStyleInfo(
            name="TableStyleLight9", showRowStripes=False, showColumnStripes=False
        )
        ws.add_table(table)

    ws.freeze_panes = "A2"
    ws.auto_filter.ref = ws.dimensions

    _add_summary_sheet(wb, jobs)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    wb.save(path)
    return path


def _add_summary_sheet(wb, jobs):
    ws = wb.create_sheet("Summary")
    ws.column_dimensions["A"].width = 34
    ws.column_dimensions["B"].width = 58

    def row(label, value, bold=False):
        r = ws.max_row + 1
        a = ws.cell(row=r, column=1, value=label)
        a.font = Font(bold=True, color="102A43")
        b = ws.cell(row=r, column=2, value=value)
        b.font = Font(bold=bold)
        b.alignment = Alignment(wrap_text=True, vertical="top")

    title = ws.cell(row=1, column=1, value="Daily Job Match Digest")
    title.font = Font(bold=True, size=14, color="102A43")

    row("Run date", dt.datetime.now().strftime("%d %b %Y, %H:%M"))
    row("Candidate", "Vipul Mayekar - Senior Cloud DevOps Engineer, IDFC FIRST BANK")
    row("Target roles", "Senior Platform Engineer / Senior DevOps Engineer / "
                        "Cloud-Platform SRE / Senior Cloud Engineer")
    row("Expected CTC", "INR 25,00,000 - 30,00,000")
    row("Roles in this report", len(jobs), bold=True)

    if jobs:
        row("Highest score", f"{jobs[0]['match_score']} - {jobs[0]['title']} @ {jobs[0]['company']}")
        row("Score range", f"{jobs[-1]['match_score']} to {jobs[0]['match_score']}")

        by_family = {}
        for j in jobs:
            key = j.get("role_family", "?")
            by_family[key] = by_family.get(key, 0) + 1
        ws.cell(row=ws.max_row + 2, column=1, value="By role family").font = Font(
            bold=True, size=12, color="102A43"
        )
        for fam, n in sorted(by_family.items(), key=lambda kv: -kv[1]):
            row(fam, n)

        by_source = {}
        for j in jobs:
            by_source[j.get("source", "?")] = by_source.get(j.get("source", "?"), 0) + 1
        ws.cell(row=ws.max_row + 2, column=1, value="Coverage").font = Font(
            bold=True, size=12, color="102A43"
        )
        row("By source", ", ".join(f"{k}: {v}" for k, v in sorted(by_source.items())))
        remote = sum(1 for j in jobs if "remote" in (j.get("location", "") or "").lower())
        row("Remote-friendly", remote)
        mumbai = sum(1 for j in jobs
                     if any(c in (j.get("location", "") or "").lower()
                            for c in ("mumbai", "thane", "navi mumbai")))
        row("Mumbai (no relocation)", mumbai)

    ws.cell(row=ws.max_row + 2, column=1, value="Scoring model").font = Font(
        bold=True, size=12, color="102A43"
    )
    row("Skills", "55 pts - weighted overlap with AWS/EKS/Terraform/Jenkins/Airflow/"
                  "observability plus SRE competencies (SLO, reliability, incident, HA)")
    row("Title", "15 pts - alignment with the four target role families")
    row("Seniority", "10 pts - years-required window vs 3.3 yrs actual")
    row("Location", "10 pts - Mumbai cluster and remote score highest")
    row("Domain", "10 pts - fintech/banking/data-platform/multi-tenant SaaS signals")


def send_email(xlsx_path, jobs):
    cfg = EMAIL
    if not cfg["smtp_password"]:
        log.warning("JOBHUNT_SMTP_PASSWORD not set - email skipped, file saved at %s", xlsx_path)
        return False

    msg = EmailMessage()
    today = dt.datetime.now().strftime("%d %b %Y")
    mumbai = sum(1 for j in jobs
                 if any(c in (j.get("location", "") or "").lower()
                        for c in ("mumbai", "thane", "navi mumbai")))
    msg["Subject"] = (f"Job Matches - {today} - Top {len(jobs)} roles"
                      + (f" ({mumbai} in Mumbai)" if mumbai else ""))
    msg["From"] = cfg["from"]
    msg["To"] = cfg["to"]

    lines = [
        f"Top {len(jobs)} roles matching your profile.",
        "",
        "Highest matches:",
    ]
    for i, j in enumerate(jobs[:15], start=1):
        lines.append(
            f"  {i:>2}. {j['match_score']}  {j['title']} - {j['company']} "
            f"({j.get('location') or 'n/a'})"
        )
    lines += ["", "Full list with links, HR contacts and match reasoning is attached.", ""]
    msg.set_content("\n".join(lines))
    msg.add_alternative(_html_body(jobs), subtype="html")

    with open(xlsx_path, "rb") as fh:
        msg.add_attachment(
            fh.read(),
            maintype="application",
            subtype="vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            filename=os.path.basename(xlsx_path),
        )

    with smtplib.SMTP(cfg["smtp_host"], cfg["smtp_port"]) as smtp:
        smtp.starttls()
        smtp.login(cfg["smtp_user"], cfg["smtp_password"])
        smtp.send_message(msg)
    log.info("email sent to %s", cfg["to"])
    return True


def _html_body(jobs):
    rows = []
    for i, j in enumerate(jobs, start=1):
        colour = "#D6EFD8" if j["match_score"] >= 90 else (
            "#FFF4CE" if j["match_score"] >= 85 else "#FFFFFF")
        rows.append(
            f"<tr style='background:{colour}'>"
            f"<td align='center' style='color:#888'>{i}</td>"
            f"<td><b>{_esc(j.get('title'))}</b></td>"
            f"<td>{_esc(j.get('company'))}</td>"
            f"<td>{_esc(j.get('location') or 'n/a')}</td>"
            f"<td align='center'><b>{j['match_score']}</b></td>"
            f"<td style='font-size:12px;color:#555'>{_esc(j.get('role_family'))}</td>"
            f"<td>{_esc(j.get('hr_contact') or '-')}</td>"
            f"<td><a href='{_esc(j.get('url'))}'>Apply</a></td>"
            f"</tr>"
        )

    by_family = {}
    for j in jobs:
        key = j.get("role_family", "?")
        by_family[key] = by_family.get(key, 0) + 1
    breakdown = " &middot; ".join(
        f"{k}: <b>{v}</b>" for k, v in sorted(by_family.items(), key=lambda kv: -kv[1])
    )

    return f"""<html><body style="font-family:Calibri,Arial,sans-serif;font-size:14px;color:#222">
<h2 style="color:#102A43;margin-bottom:4px">Daily Job Matches</h2>
<p style="margin-top:0;color:#555">Top {len(jobs)} roles &middot;
Platform / DevOps / SRE / Cloud &middot; target CTC INR 25-30L</p>
<p style="color:#555;margin-top:0">{breakdown}</p>
<table cellpadding="7" cellspacing="0" border="0"
 style="border-collapse:collapse;border:1px solid #ccd">
<tr style="background:#102A43;color:#fff">
<th>#</th><th align="left">Job Title</th><th align="left">Company</th>
<th align="left">Location</th><th>Score</th><th align="left">Role Family</th>
<th align="left">HR Contact</th><th>Link</th></tr>
{''.join(rows)}
</table>
<p style="color:#555">Match reasoning, matched skills and the full ranked list are in
the attached spreadsheet.</p>
</body></html>"""


def _esc(text):
    return (str(text or "").replace("&", "&amp;").replace("<", "&lt;")
            .replace(">", "&gt;").replace('"', "&quot;"))


def output_path():
    stamp = dt.datetime.now().strftime("%Y-%m-%d")
    return os.path.join(OUTPUT_DIR, f"job_matches_{stamp}.xlsx")
