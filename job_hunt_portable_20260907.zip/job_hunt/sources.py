# -*- coding: utf-8 -*-
"""
Job source connectors.

Every connector returns a list of dicts with a common shape:
    title, company, location, url, description, posted_at (ISO str or ''),
    source, salary, hr_contact

Only public JSON APIs / official feeds are used, so nothing here depends on
scraping HTML that changes weekly. LinkedIn, Indeed and Naukri are reached
through Google Jobs (SerpApi) and Adzuna, which is the supported route.
"""
import datetime as dt
import json
import logging
import re
import urllib.parse

import requests

from config import (
    ADZUNA_APP_ID,
    ADZUNA_APP_KEY,
    ADZUNA_LOCATIONS,
    ADZUNA_QUERIES,
    ASHBY_ORGS,
    GREENHOUSE_BOARDS,
    HTTP_TIMEOUT,
    JOOBLE_API_KEY,
    LEVER_COMPANIES,
    REMOTEOK_ENABLED,
    SERPAPI_KEY,
    SERPAPI_QUERIES,
    USER_AGENT,
)

log = logging.getLogger("sources")
SESSION = requests.Session()
SESSION.headers.update({
    "User-Agent": USER_AGENT,
    "Accept": "application/json, text/plain, */*",
    "Accept-Language": "en-US,en;q=0.9",
})

TAG_RE = re.compile(r"<[^>]+>")

# Corporate web-proxy interception. On the IDFC FIRST network Netskope returns a
# 403 HTML interstitial for URL category "HR", which covers most job boards.
# We detect it so the run reports a network problem instead of "0 matches".
PROXY_BLOCK_MARKERS = ("SWG Policy", "Internet access policy", "netskope", "Blocked by")
BLOCKED_HOSTS = set()


def _looks_blocked(response):
    if response.status_code not in (403, 407, 451):
        return False
    body = response.text[:4000]
    return any(marker.lower() in body.lower() for marker in PROXY_BLOCK_MARKERS)


def _clean(html):
    if not html:
        return ""
    text = TAG_RE.sub(" ", str(html))
    text = (text.replace("&nbsp;", " ").replace("&amp;", "&")
                .replace("&lt;", "<").replace("&gt;", ">")
                .replace("&#39;", "'").replace("&quot;", '"'))
    return re.sub(r"\s+", " ", text).strip()


def _get(url, params=None):
    host = urllib.parse.urlparse(url).netloc
    try:
        r = SESSION.get(url, params=params, timeout=HTTP_TIMEOUT)
        if _looks_blocked(r):
            if host not in BLOCKED_HOSTS:
                BLOCKED_HOSTS.add(host)
                log.warning("BLOCKED BY CORPORATE PROXY: %s "
                            "(run this from a personal network)", host)
            return None
        if r.status_code != 200:
            log.warning("HTTP %s for %s", r.status_code, url)
            return None
        return r.json()
    except (requests.RequestException, json.JSONDecodeError) as exc:
        log.warning("fetch failed %s: %s", url, exc)
        return None


def _iso(ts):
    """Normalise assorted timestamp formats to YYYY-MM-DD."""
    if not ts:
        return ""
    if isinstance(ts, (int, float)):
        try:
            return dt.datetime.utcfromtimestamp(ts / (1000 if ts > 1e11 else 1)).strftime("%Y-%m-%d")
        except (ValueError, OSError):
            return ""
    s = str(ts)[:19].replace("Z", "")
    for fmt in ("%Y-%m-%dT%H:%M:%S", "%Y-%m-%d %H:%M:%S", "%Y-%m-%d"):
        try:
            return dt.datetime.strptime(s, fmt).strftime("%Y-%m-%d")
        except ValueError:
            continue
    return ""


# ---------------------------------------------------------------------------
# GREENHOUSE  (public board API, no key required)
# ---------------------------------------------------------------------------
def fetch_greenhouse():
    out = []
    for token in GREENHOUSE_BOARDS:
        data = _get(
            f"https://boards-api.greenhouse.io/v1/boards/{token}/jobs",
            params={"content": "true"},
        )
        if not data or "jobs" not in data:
            continue
        for j in data["jobs"]:
            loc = (j.get("location") or {}).get("name", "")
            out.append({
                "title": j.get("title", ""),
                "company": token.replace("-", " ").title(),
                "location": loc,
                "url": j.get("absolute_url", ""),
                "description": _clean(j.get("content", ""))[:6000],
                "posted_at": _iso(j.get("updated_at") or j.get("created_at")),
                "source": "Greenhouse",
                "salary": "",
                "hr_contact": "",
            })
    log.info("Greenhouse: %d raw postings", len(out))
    return out


# ---------------------------------------------------------------------------
# LEVER  (public postings API, no key required)
# ---------------------------------------------------------------------------
def fetch_lever():
    out = []
    for slug in LEVER_COMPANIES:
        data = _get(f"https://api.lever.co/v0/postings/{slug}", params={"mode": "json"})
        if not isinstance(data, list):
            continue
        for j in data:
            cats = j.get("categories") or {}
            out.append({
                "title": j.get("text", ""),
                "company": slug.replace("-", " ").title(),
                "location": cats.get("location", ""),
                "url": j.get("hostedUrl", ""),
                "description": _clean(
                    (j.get("descriptionPlain") or j.get("description") or "")
                    + " " + " ".join(
                        _clean(l.get("text", "")) + " " + " ".join(
                            _clean(x) for x in (l.get("content") or [])
                        )
                        for l in (j.get("lists") or [])
                    )
                )[:6000],
                "posted_at": _iso(j.get("createdAt")),
                "source": "Lever",
                "salary": cats.get("commitment", "") or "",
                "hr_contact": "",
            })
    log.info("Lever: %d raw postings", len(out))
    return out


# ---------------------------------------------------------------------------
# ASHBY  (public job-board API)
# ---------------------------------------------------------------------------
def fetch_ashby():
    out = []
    for org in ASHBY_ORGS:
        data = _get(
            "https://api.ashbyhq.com/posting-api/job-board/" + org,
            params={"includeCompensation": "true"},
        )
        if not data or "jobs" not in data:
            continue
        for j in data["jobs"]:
            out.append({
                "title": j.get("title", ""),
                "company": org.title(),
                "location": j.get("location", ""),
                "url": j.get("jobUrl", ""),
                "description": _clean(j.get("descriptionHtml", ""))[:6000],
                "posted_at": _iso(j.get("publishedAt")),
                "source": "Ashby",
                "salary": _clean(str(j.get("compensationTierSummary") or "")),
                "hr_contact": "",
            })
    log.info("Ashby: %d raw postings", len(out))
    return out


# ---------------------------------------------------------------------------
# REMOTEOK  (open JSON feed, remote-only roles)
# ---------------------------------------------------------------------------
def fetch_remoteok():
    if not REMOTEOK_ENABLED:
        return []
    data = _get("https://remoteok.com/api")
    if not isinstance(data, list):
        return []
    out = []
    for j in data[1:]:
        out.append({
            "title": j.get("position", ""),
            "company": j.get("company", ""),
            "location": j.get("location") or "Remote",
            "url": j.get("url", ""),
            "description": _clean(j.get("description", ""))[:6000],
            "posted_at": _iso(j.get("date")),
            "source": "RemoteOK",
            "salary": j.get("salary", "") or "",
            "hr_contact": "",
        })
    log.info("RemoteOK: %d raw postings", len(out))
    return out


# ---------------------------------------------------------------------------
# ADZUNA  (aggregates Indeed, LinkedIn feeds, Naukri and direct career pages)
# Free tier: register at developer.adzuna.com
# ---------------------------------------------------------------------------
def fetch_adzuna():
    if not (ADZUNA_APP_ID and ADZUNA_APP_KEY):
        log.info("Adzuna: skipped (no credentials)")
        return []
    out = []
    for query in ADZUNA_QUERIES:
        for city in ADZUNA_LOCATIONS:
            data = _get(
                "https://api.adzuna.com/v1/api/jobs/in/search/1",
                params={
                    "app_id": ADZUNA_APP_ID,
                    "app_key": ADZUNA_APP_KEY,
                    "results_per_page": 50,
                    "what": query,
                    "where": city,
                    "max_days_old": 21,
                    "content-type": "application/json",
                },
            )
            for j in (data or {}).get("results", []):
                sal_min = j.get("salary_min")
                sal_max = j.get("salary_max")
                out.append({
                    "title": j.get("title", ""),
                    "company": (j.get("company") or {}).get("display_name", ""),
                    "location": (j.get("location") or {}).get("display_name", ""),
                    "url": j.get("redirect_url", ""),
                    "description": _clean(j.get("description", ""))[:6000],
                    "posted_at": _iso(j.get("created")),
                    "source": "Adzuna",
                    "salary": (
                        f"INR {int(sal_min):,} - {int(sal_max):,}"
                        if sal_min and sal_max else ""
                    ),
                    "hr_contact": "",
                })
    log.info("Adzuna: %d raw postings", len(out))
    return out


# ---------------------------------------------------------------------------
# JOOBLE  (aggregator, free API key on request)
# ---------------------------------------------------------------------------
def fetch_jooble():
    if not JOOBLE_API_KEY:
        log.info("Jooble: skipped (no key)")
        return []
    out = []
    for query in ADZUNA_QUERIES:
        try:
            r = SESSION.post(
                f"https://in.jooble.org/api/{JOOBLE_API_KEY}",
                json={"keywords": query, "location": "India", "page": "1"},
                timeout=HTTP_TIMEOUT,
            )
            payload = r.json()
        except (requests.RequestException, json.JSONDecodeError) as exc:
            log.warning("Jooble failed: %s", exc)
            continue
        for j in payload.get("jobs", []):
            out.append({
                "title": j.get("title", ""),
                "company": j.get("company", ""),
                "location": j.get("location", ""),
                "url": j.get("link", ""),
                "description": _clean(j.get("snippet", ""))[:6000],
                "posted_at": _iso(j.get("updated")),
                "source": "Jooble",
                "salary": j.get("salary", "") or "",
                "hr_contact": "",
            })
    log.info("Jooble: %d raw postings", len(out))
    return out


# ---------------------------------------------------------------------------
# GOOGLE JOBS via SERPAPI  -> this is the LinkedIn / Indeed / Naukri channel
# ---------------------------------------------------------------------------
def fetch_google_jobs():
    if not SERPAPI_KEY:
        log.info("Google Jobs (SerpApi): skipped (no key)")
        return []
    out = []
    for query in SERPAPI_QUERIES:
        data = _get(
            "https://serpapi.com/search.json",
            params={
                "engine": "google_jobs",
                "q": query,
                "location": "India",
                "hl": "en",
                "gl": "in",
                "chips": "date_posted:month",
                "api_key": SERPAPI_KEY,
            },
        )
        for j in (data or {}).get("jobs_results", []):
            apply_links = j.get("apply_options") or []
            url = apply_links[0].get("link") if apply_links else j.get("share_link", "")
            detected = j.get("detected_extensions") or {}
            out.append({
                "title": j.get("title", ""),
                "company": j.get("company_name", ""),
                "location": j.get("location", ""),
                "url": url or "",
                "description": _clean(j.get("description", ""))[:6000],
                "posted_at": "",
                "posted_relative": detected.get("posted_at", ""),
                "source": "Google Jobs (LinkedIn/Indeed/Naukri)",
                "salary": detected.get("salary", "") or "",
                "hr_contact": "",
            })
    log.info("Google Jobs: %d raw postings", len(out))
    return out


# ---------------------------------------------------------------------------
# HR CONTACT DISCOVERY
# ---------------------------------------------------------------------------
EMAIL_RE = re.compile(r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}")
PHONE_RE = re.compile(r"(?:\+91[\-\s]?)?[6-9]\d{9}\b")

GENERIC_PREFIXES = ("noreply", "no-reply", "donotreply", "privacy", "legal",
                    "support", "info", "sales", "marketing")


def find_hr_contact(job):
    """Pull a recruiter email/phone out of the JD when the company published one."""
    blob = f"{job.get('description','')} {job.get('requirements','')}"
    for email in EMAIL_RE.findall(blob):
        local = email.split("@")[0].lower()
        if local.startswith(GENERIC_PREFIXES):
            continue
        return email
    phones = PHONE_RE.findall(blob)
    if phones:
        return phones[0]
    return ""


# ---------------------------------------------------------------------------
ALL_SOURCES = [
    fetch_greenhouse,
    fetch_lever,
    fetch_ashby,
    fetch_remoteok,
    fetch_adzuna,
    fetch_jooble,
    fetch_google_jobs,
]


def fetch_all():
    jobs = []
    for fn in ALL_SOURCES:
        try:
            jobs.extend(fn())
        except Exception as exc:                       # a dead source must not kill the run
            log.error("source %s crashed: %s", fn.__name__, exc)
    if BLOCKED_HOSTS:
        log.warning(
            "%d source host(s) were blocked by the corporate web proxy: %s. "
            "Schedule this script on a personal machine/network for full coverage.",
            len(BLOCKED_HOSTS), ", ".join(sorted(BLOCKED_HOSTS)),
        )
    return jobs
