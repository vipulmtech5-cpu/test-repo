# -*- coding: utf-8 -*-
"""
Scoring engine: turns a raw job posting into a 0-100 match score plus a
human-readable reason explaining why the profile fits.

Score composition (100 total):
  55  skill overlap, weighted by how central each skill is to the CV
  15  title alignment with the three target roles
  10  seniority / years-of-experience window
  10  location fit
  10  domain + scale signals (fintech, data platform, multi-tenant SaaS)
Penalties are applied for off-stack tooling (Azure/GCP-first roles).
"""
import re

from config import (
    BANK_GRADE_PATTERNS,
    EXCLUDE_TITLE_PATTERNS,
    NEGATIVE_SKILLS,
    PREFERRED_LOCATIONS,
    ROLE_FAMILIES,
    SKILL_WEIGHTS,
    TARGET_TITLE_PATTERNS,
    YEARS_MAX_ACCEPTABLE,
)

# Skill aliases so "Amazon EKS", "K8s", "CICD" all resolve correctly.
ALIASES = {
    "reliability": ["reliability", "resilience", "resiliency", "fault-tolerant",
                    "fault tolerant"],
    "high availability": ["high availability", "highly available", "ha ", "failover"],
    "disaster recovery": ["disaster recovery", " dr ", "rto", "rpo", "backup"],
    "capacity planning": ["capacity planning", "capacity management", "right-sizing",
                          "right sizing"],
    "distributed tracing": ["distributed tracing", "tracing", "jaeger", "traces"],
    "runbook": ["runbook", "playbook"],
    "chaos": ["chaos engineering", "chaos testing", "game day"],
    "kubernetes": ["kubernetes", "k8s"],
    "eks": ["eks", "elastic kubernetes"],
    "ci/cd": ["ci/cd", "cicd", "ci cd", "continuous integration", "continuous delivery"],
    "elk": ["elk", "elasticsearch", "opensearch", "kibana", "logstash", "efk"],
    "cost optimization": ["cost optimization", "cost optimisation", "cost efficiency",
                          "cost governance", "cloud cost"],
    "autoscaling": ["autoscaling", "auto-scaling", "auto scaling", "hpa", "cluster autoscaler"],
    "observability": ["observability", "monitoring", "telemetry"],
    "github actions": ["github actions", "gh actions"],
    "service mesh": ["service mesh", "istio", "linkerd"],
    "incident": ["incident response", "incident management", "on-call", "oncall", "postmortem"],
    "slo": ["slo", "sla", "error budget"],
    "gcp": ["gcp", "google cloud"],
    "airflow": ["airflow", "mwaa"],
}

# Domains where the banking / data-platform background is a direct advantage.
DOMAIN_SIGNALS = {
    "fintech": 4, "payments": 4, "banking": 5, "bank": 4, "lending": 4,
    "nbfc": 4, "insurance": 3, "capital markets": 3, "trading": 3,
    "data platform": 5, "data engineering": 4, "lakehouse": 3, "analytics": 3,
    "machine learning": 2, "mlops": 3,
    "multi-tenant": 3, "saas": 2, "regulated": 3, "compliance": 2,
    "internal developer platform": 4, "developer platform": 4,
}

_YEARS_RE = [
    re.compile(r"(\d+)\s*\+?\s*(?:to|-|–)\s*(\d+)\s*\+?\s*years", re.I),
    re.compile(r"(\d+)\s*\+\s*years", re.I),
    re.compile(r"minimum\s+of\s+(\d+)\s*years", re.I),
    re.compile(r"at\s+least\s+(\d+)\s*years", re.I),
]


def _variants(skill):
    return ALIASES.get(skill, [skill])


def extract_years_required(text):
    """Return (min_years, max_years) if the posting states a window."""
    low = text.lower()
    for pattern in _YEARS_RE:
        m = pattern.search(low)
        if not m:
            continue
        groups = [int(g) for g in m.groups() if g]
        if len(groups) == 2:
            return groups[0], groups[1]
        return groups[0], groups[0] + 3
    return None, None


def is_bank_ic_grade(title):
    """True when a VP/AVP/Associate label is a pay grade on an engineering IC role."""
    low = (title or "").lower()
    if not re.search(r"engineer|sre|developer", low):
        return False
    return any(re.search(p, low) for p in BANK_GRADE_PATTERNS)


def title_is_relevant(title):
    low = (title or "").lower()
    bank_ic = is_bank_ic_grade(low)
    for pattern in EXCLUDE_TITLE_PATTERNS:
        if re.search(pattern, low):
            # "VP - Senior DevOps Engineer" at a bank is an IC role, keep it.
            if bank_ic and re.search(r"\bvp\b|\bvice president\b|\bassociate\b", pattern):
                continue
            return False
    return any(re.search(p, low) for p in TARGET_TITLE_PATTERNS)


def _score_skills(text):
    """Weighted skill overlap, normalised to 55 points."""
    low = text.lower()
    matched, missing = [], []
    earned = 0
    mentioned_total = 0

    for skill, weight in SKILL_WEIGHTS.items():
        present = any(v in low for v in _variants(skill))
        if present:
            mentioned_total += weight
            earned += weight
            matched.append(skill)

    penalty = 0
    off_stack = []
    for skill, weight in NEGATIVE_SKILLS.items():
        if any(v in low for v in _variants(skill)):
            penalty += weight
            off_stack.append(skill)

    # Normalise: a posting mentioning ~60 weight-points of our core stack is a
    # very strong match. Cap so long JDs are not unfairly advantaged.
    raw = min(earned / 60.0, 1.0) * 55.0
    raw -= min(penalty, 12)
    return max(raw, 0.0), matched, off_stack


def role_family(title):
    """Label the posting with one of the four target role families."""
    low = (title or "").lower()
    for label, pattern in ROLE_FAMILIES:
        if re.search(pattern, low):
            return label
    return "Adjacent / Infrastructure"


def _score_title(title):
    low = (title or "").lower()
    senior = re.search(r"\b(senior|sr\.?|lead|specialist|ii|iii)\b", low)
    on_target = re.search(
        r"devops|devsecops|platform|cloud|reliability|sre|infrastructure|kubernetes", low
    )
    if senior and on_target:
        return 15.0
    if re.search(
        r"devops|platform engineer|cloud engineer|sre|site reliability|"
        r"service reliability|reliability engineer|production engineer", low
    ):
        return 11.0
    if re.search(r"infrastructure|systems engineer|kubernetes|automation engineer", low):
        return 8.0
    return 4.0


def _score_seniority(text):
    lo, hi = extract_years_required(text)
    if lo is None:
        return 7.0, "years not stated"
    if lo <= 3:
        return 10.0, f"asks {lo}+ yrs"
    if lo == 4:
        return 8.5, f"asks {lo}+ yrs"
    if lo == 5:
        return 6.0, f"asks {lo}+ yrs (slight stretch)"
    if lo <= YEARS_MAX_ACCEPTABLE:
        return 3.5, f"asks {lo}+ yrs (stretch)"
    return 1.0, f"asks {lo}+ yrs (well above current 3.3)"


def _score_location(location, text):
    low = f"{location or ''} {text or ''}".lower()
    if "remote" in low or "anywhere" in low or "work from home" in low:
        return 10.0
    for i, city in enumerate(PREFERRED_LOCATIONS):
        if city in (location or "").lower():
            # Mumbai cluster scores highest, then metros
            return 10.0 if i <= 4 else 8.0
    if "india" in low:
        return 7.0
    return 3.0


def _score_domain(text):
    low = text.lower()
    hits, pts = [], 0
    for signal, weight in DOMAIN_SIGNALS.items():
        if signal in low:
            pts += weight
            hits.append(signal)
    return min(pts, 10.0), hits[:4]


def score_job(job):
    """Attach match_score and match_reason to a job dict. Returns the job."""
    text = " ".join(
        str(job.get(k, "") or "")
        for k in ("title", "description", "requirements", "company", "location")
    )

    skill_pts, matched, off_stack = _score_skills(text)
    title_pts = _score_title(job.get("title"))
    senior_pts, senior_note = _score_seniority(text)
    loc_pts = _score_location(job.get("location"), text)
    domain_pts, domain_hits = _score_domain(text)

    total = skill_pts + title_pts + senior_pts + loc_pts + domain_pts
    total = round(min(total, 99.0), 1)

    # ----- build the reason -----
    core = [s for s in matched if SKILL_WEIGHTS.get(s, 0) >= 8]
    strong = [s for s in matched if 5 <= SKILL_WEIGHTS.get(s, 0) < 8]

    parts = []
    if core:
        parts.append("Direct overlap on core stack: " + ", ".join(_pretty(core[:7])))
    if strong:
        parts.append("plus " + ", ".join(_pretty(strong[:5])))
    if domain_hits:
        parts.append(
            "Domain fit (" + ", ".join(domain_hits)
            + ") maps to banking / data-platform experience at IDFC FIRST"
        )
    parts.append(senior_note.capitalize())
    if off_stack:
        parts.append("Watch-out: JD leans on " + ", ".join(_pretty(off_stack)))

    job["match_score"] = total
    job["role_family"] = role_family(job.get("title"))
    job["match_reason"] = ". ".join(parts) + "."
    job["matched_skills"] = ", ".join(_pretty(matched[:14]))
    job["score_breakdown"] = (
        f"skills {skill_pts:.0f}/55 | title {title_pts:.0f}/15 | "
        f"seniority {senior_pts:.0f}/10 | location {loc_pts:.0f}/10 | "
        f"domain {domain_pts:.0f}/10"
    )
    return job


_PRETTY = {
    "aws": "AWS", "eks": "EKS", "ecs": "ECS", "ci/cd": "CI/CD", "elk": "ELK",
    "iam": "IAM", "vpc": "VPC", "emr": "EMR", "keda": "KEDA", "sre": "SRE",
    "slo": "SLO/SLA", "gcp": "GCP", "argocd": "ArgoCD", "gitops": "GitOps",
    "opentelemetry": "OpenTelemetry", ".net": ".NET", "finops": "FinOps",
}


def _pretty(items):
    return [_PRETTY.get(i, i.title() if i.islower() else i) for i in items]
