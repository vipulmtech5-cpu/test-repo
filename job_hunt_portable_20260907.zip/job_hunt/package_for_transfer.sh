#!/bin/bash
# Builds a clean, portable zip of this folder for transfer to your personal Mac.
#
# Excludes machine-local and sensitive artefacts:
#   .env  (your Gmail app password)   reports/   *.log   seen_jobs.json
#   __pycache__/                      launchd.*.log
#
#   bash package_for_transfer.sh
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PARENT_DIR="$(dirname "$SCRIPT_DIR")"
FOLDER_NAME="$(basename "$SCRIPT_DIR")"
STAMP="$(date +%Y%m%d)"
ZIP_PATH="${PARENT_DIR}/job_hunt_portable_${STAMP}.zip"

rm -f "$ZIP_PATH"

cd "$PARENT_DIR"
zip -r "$ZIP_PATH" "$FOLDER_NAME" \
  -x "${FOLDER_NAME}/.env" \
  -x "${FOLDER_NAME}/reports/*" \
  -x "${FOLDER_NAME}/__pycache__/*" \
  -x "${FOLDER_NAME}/*.pyc" \
  -x "${FOLDER_NAME}/*.log" \
  -x "${FOLDER_NAME}/seen_jobs.json" \
  -x "${FOLDER_NAME}/.DS_Store" \
  -x "${FOLDER_NAME}/*/.DS_Store" \
  > /dev/null

echo "Created: $ZIP_PATH"
echo
echo "Contents:"
unzip -Z1 "$ZIP_PATH" | sed 's/^/  /'
echo
echo "Excluded on purpose: .env (secrets), reports/, logs, seen_jobs.json, __pycache__"
echo
echo "On your personal Mac:"
echo "  1. unzip job_hunt_portable_${STAMP}.zip"
echo "  2. cd job_hunt && bash bootstrap.sh"
