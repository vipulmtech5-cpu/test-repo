#!/bin/bash
# One-shot setup on a fresh (personal) Mac.
# Verifies Python, installs dependencies, creates .env, runs a connectivity
# check and a dry run. Does NOT schedule anything - that is setup_schedule.sh.
#
#   bash bootstrap.sh
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

echo "=============================================================="
echo " Job Hunt Automation - setup"
echo "=============================================================="
echo

if ! command -v python3 >/dev/null 2>&1; then
  echo "ERROR: python3 not found. Install it with:  brew install python3"
  exit 1
fi
echo "Python: $(python3 --version)"

echo
echo "Installing dependencies (requests, openpyxl)..."
python3 -m pip install --quiet --user --upgrade requests openpyxl 2>&1 \
  | grep -v "already satisfied" || true
python3 -c "import requests, openpyxl; print('Dependencies OK')"

if [[ ! -f .env ]]; then
  cp .env.example .env
  echo
  echo ".env created from the template."
else
  echo
  echo ".env already present, leaving it untouched."
fi

echo
echo "--- Source connectivity check ---"
python3 - <<'PYCHECK'
import requests
targets = {
    "Greenhouse": "https://boards-api.greenhouse.io/v1/boards/amtechsoftware/jobs",
    "Lever":      "https://api.lever.co/v0/postings/razorpay?mode=json",
    "Ashby":      "https://api.ashbyhq.com/posting-api/job-board/nirvana",
    "RemoteOK":   "https://remoteok.com/api",
}
blocked = ok = 0
for name, url in targets.items():
    try:
        r = requests.get(url, timeout=15, headers={"User-Agent": "Mozilla/5.0"})
        if r.status_code == 200:
            print(f"  {name:<12} reachable"); ok += 1
        elif "SWG Policy" in r.text or "Internet access policy" in r.text:
            print(f"  {name:<12} BLOCKED by a web proxy"); blocked += 1
        else:
            print(f"  {name:<12} HTTP {r.status_code}")
    except Exception as exc:
        print(f"  {name:<12} error: {type(exc).__name__}")
print()
if blocked:
    print(f"  {blocked} source(s) blocked - you are still on a filtered network.")
    print("  Move to a personal / home network for full coverage.")
else:
    print(f"  All {ok} sources reachable. This network is good to go.")
PYCHECK

echo
echo "--- Dry run (builds the sheet, sends nothing) ---"
python3 daily_job_hunt.py --seed --no-email 2>&1 | tail -12

echo
echo "=============================================================="
echo " Next steps"
echo "=============================================================="
echo "  1. Add your Gmail app password to .env  (JOBHUNT_SMTP_PASSWORD)"
echo "     Google Account -> Security -> 2-Step Verification -> App passwords"
echo "  2. Optional but recommended: add SERPAPI_KEY for LinkedIn/Indeed/Naukri"
echo "  3. Send a real email:   python3 daily_job_hunt.py --seed --show-all"
echo "  4. Schedule it daily:   bash setup_schedule.sh"
echo
