#!/bin/bash
# Installs the daily job-hunt run as a macOS LaunchAgent (fires at 08:30 daily,
# and catches up on the next wake if the Mac was asleep).
#
#   bash setup_schedule.sh          # install / reload
#   bash setup_schedule.sh remove   # uninstall
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
LABEL="com.vipul.jobhunt"
PLIST="$HOME/Library/LaunchAgents/${LABEL}.plist"
PYTHON="$(command -v python3)"

if [[ "${1:-}" == "remove" ]]; then
  launchctl unload "$PLIST" 2>/dev/null || true
  rm -f "$PLIST"
  echo "Removed $LABEL"
  exit 0
fi

if [[ ! -f "$SCRIPT_DIR/.env" ]]; then
  echo "WARNING: $SCRIPT_DIR/.env not found."
  echo "Create it from .env.example first, or the run will build the sheet but not email."
fi

mkdir -p "$HOME/Library/LaunchAgents"

cat > "$PLIST" <<PLIST_EOF
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN"
  "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>Label</key><string>${LABEL}</string>
  <key>ProgramArguments</key>
  <array>
    <string>/bin/bash</string>
    <string>-lc</string>
    <string>cd '${SCRIPT_DIR}' &amp;&amp; set -a &amp;&amp; [ -f .env ] &amp;&amp; . ./.env; set +a; '${PYTHON}' daily_job_hunt.py --seed</string>
  </array>
  <key>StartCalendarInterval</key>
  <dict>
    <key>Hour</key><integer>8</integer>
    <key>Minute</key><integer>30</integer>
  </dict>
  <key>RunAtLoad</key><false/>
  <key>StandardOutPath</key><string>${SCRIPT_DIR}/launchd.out.log</string>
  <key>StandardErrorPath</key><string>${SCRIPT_DIR}/launchd.err.log</string>
  <key>WorkingDirectory</key><string>${SCRIPT_DIR}</string>
</dict>
</plist>
PLIST_EOF

launchctl unload "$PLIST" 2>/dev/null || true
launchctl load "$PLIST"

echo "Installed $LABEL -> runs daily at 08:30"
echo "Plist:  $PLIST"
echo "Logs:   $SCRIPT_DIR/launchd.out.log"
echo
echo "Test it right now with:"
echo "  launchctl start $LABEL"
