# -*- coding: utf-8 -*-
"""
Live roles found during the manual search on 06 Sep 2026.

This module doubles as (a) the starting shortlist and (b) a scoring fixture, so
`--seed` can produce today's report even while the corporate proxy blocks the
board APIs. Descriptions are condensed paraphrases of each JD (kept short for
licensing compliance); the URL is always the authoritative source.
"""

SEED_JOBS = [
    {
        "title": "Senior Cloud Engineer (Enterprise IT)",
        "company": "ZS",
        "location": "Pune / Bengaluru, India",
        "url": "https://builtin.com/job/senior-cloud-engineer/10138452",
        "source": "Built In (ZS careers)",
        "posted_at": "2026-08-25",
        "salary": "",
        "hr_contact": "",
        "description": (
            "Design, provision, configure and manage large-scale Kubernetes clusters "
            "primarily on Amazon EKS with high availability, scalability and security. "
            "Automate AWS infrastructure with Terraform, operate CI/CD pipelines, Helm "
            "releases, Docker images, autoscaling, observability with Prometheus and "
            "Grafana, IAM and VPC security, cost optimization. Python and Bash scripting "
            "on Linux. 4+ years of cloud engineering experience."
        ),
    },
    {
        "title": "Cloud SRE (Platform and Kubernetes)",
        "company": "Jefferies",
        "location": "Mumbai, India",
        "url": "https://builtin.com/job/cloud-sre-platform-and-kubernetes/10518267",
        "source": "Built In (Jefferies careers)",
        "posted_at": "2026-09-02",
        "salary": "",
        "hr_contact": "",
        "description": (
            "Cloud Infrastructure team role focused on AWS EKS platform operations. "
            "Support Kubernetes infrastructure, drive automation through Terraform and "
            "GitOps, participate in incident response and on-call, ensure production "
            "systems meet SLO targets. Observability with Prometheus, Grafana and "
            "OpenTelemetry. Helm, Docker, CI/CD, IAM, VPC, Linux, Python. Capital "
            "markets / banking environment, regulated and compliance-driven. "
            "3+ years experience."
        ),
    },
    {
        "title": "Senior Associate - Platform Automation Engineer",
        "company": "MSCI",
        "location": "Mumbai, India",
        "url": "https://careers.msci.com/job/technology/mumbai/senior-asso-platform-automation-engineer/2026-5313",
        "source": "MSCI careers",
        "posted_at": "2026-08-31",
        "salary": "",
        "hr_contact": "",
        "description": (
            "Work with application development teams on planning and executing cloud "
            "and container transformation initiatives. Participate in architecture "
            "reviews, proof of concept implementations and technology evaluations. "
            "Kubernetes, Docker, Helm, Terraform, AWS, CI/CD pipelines, Jenkins, "
            "observability, Python automation, Linux. Capital markets / financial data "
            "platform. 4+ years experience."
        ),
    },
    {
        "title": "VP - Senior DevOps Engineer (GitHub SME)",
        "company": "MSCI",
        "location": "Mumbai, India",
        "url": "https://careers.msci.com/job/technology/mumbai/vp-senior-devops-engineer-github-sme/2026-4828",
        "source": "MSCI careers",
        "posted_at": "2026-09-04",
        "salary": "",
        "hr_contact": "",
        "description": (
            "DevOps Platform Engineering team building and operating engineering "
            "platforms, developer workflows and self-service capabilities so teams "
            "deliver software securely and reliably at scale. GitHub Actions, CI/CD, "
            "Kubernetes, Terraform, AWS, observability, internal developer platform, "
            "Python. Financial data domain. 6+ years experience."
        ),
    },
    {
        "title": "Platform Engineer (SRE - India) II",
        "company": "Amtech Software",
        "location": "India (Remote)",
        "url": "https://boards.greenhouse.io/amtechsoftware/jobs/4361631009",
        "source": "Greenhouse (Amtech)",
        "posted_at": "2026-09-01",
        "salary": "",
        "hr_contact": "",
        "description": (
            "Build and operate monitoring, automation and incident response systems for "
            "a multi-account, multi-tenant AWS SaaS platform. Design Terraform modules, "
            "CI/CD pipelines, autoscaling and self-healing, OpenTelemetry-based "
            "observability, security controls. Kubernetes, Docker, Helm, Python, Bash, "
            "Linux, SLO and error budget practice, cloud cost optimization. "
            "3+ years experience."
        ),
    },
    {
        "title": "Platform Engineer (SRE - India) III",
        "company": "Amtech Software",
        "location": "India (Remote)",
        "url": "https://builtin.com/job/platform-engineer-sre-india-iii/10615003",
        "source": "Built In (Amtech)",
        "posted_at": "2026-09-02",
        "salary": "",
        "hr_contact": "",
        "description": (
            "SRE responsible for reliability, observability, automation and incident "
            "command across a multi-account AWS SaaS estate. Design Terraform modules, "
            "CI/CD pipelines, autoscaling and self-healing, OpenTelemetry monitoring and "
            "security controls; mentor engineers. Kubernetes, EKS, Docker, Helm, Python, "
            "Linux, SLO. 4+ years experience."
        ),
    },
    {
        "title": "AWS DevOps Engineer (Data Platform)",
        "company": "EXL",
        "location": "India (Hybrid)",
        "url": "https://builtin.com/job/aws-devops-engineer/11015310",
        "source": "Built In (EXL)",
        "posted_at": "2026-09-03",
        "salary": "",
        "hr_contact": "",
        "description": (
            "Build, deploy and manage AWS cloud and data platform services including "
            "AWS Glue, Step Functions, Lambda, MSK and EKS. Expertise in automation, "
            "CI/CD, Kubernetes, GitOps, security, observability and cloud cost "
            "optimization. Terraform, Docker, Helm, Python, Bash, Linux, Airflow "
            "orchestration, Prometheus and Grafana. Data engineering and analytics "
            "platform. 4+ years experience."
        ),
    },
    {
        "title": "Senior DevOps Engineer",
        "company": "EXL",
        "location": "India (Hybrid)",
        "url": "https://builtin.com/job/senior-devops-engineer/9984861",
        "source": "Built In (EXL)",
        "posted_at": "2026-08-28",
        "salary": "",
        "hr_contact": "",
        "description": (
            "3-5 years of overall IT experience in DevOps, cloud engineering or "
            "infrastructure roles. AWS, Kubernetes, Docker, Terraform, Jenkins CI/CD, "
            "Helm, observability with Prometheus and Grafana, ELK logging, Python and "
            "Bash automation, Linux administration, IAM and VPC, cost optimization."
        ),
    },
    {
        "title": "Senior DevOps Engineer",
        "company": "Prophecy",
        "location": "India (Remote)",
        "url": "https://builtin.com/job/senior-devops-engineer/9657476",
        "source": "Built In (Prophecy)",
        "posted_at": "2026-08-25",
        "salary": "",
        "hr_contact": "",
        "description": (
            "Lead cloud cost optimization across AWS by analysing billing and usage, "
            "identifying waste and automating provisioning, scaling and cost control. "
            "Build and maintain infrastructure as code with Terraform, CI/CD pipelines, "
            "Kubernetes and EKS platforms, observability and developer productivity "
            "tooling. Docker, Helm, Python, Bash, Linux, Spark and data platform "
            "workloads. 4+ years experience."
        ),
    },
    {
        "title": "Senior DevOps Engineer",
        "company": "ixigo",
        "location": "Gurugram, India",
        "url": "https://builtin.com/job/senior-devops-engineer/10795444",
        "source": "Built In (ixigo)",
        "posted_at": "2026-09-01",
        "salary": "",
        "hr_contact": "",
        "description": (
            "Design, build, operate and scale secure, highly available AWS cloud "
            "infrastructure and Kubernetes EKS platforms. Develop Terraform "
            "infrastructure, CI/CD pipelines, containerized deployments, service mesh "
            "and gateway solutions and centralized observability. Troubleshoot "
            "production systems across Linux, networking and databases; drive incident "
            "management, capacity planning and cost optimization. Karpenter, Helm, "
            "Prometheus, Grafana, Python. 4+ years experience."
        ),
    },
    {
        "title": "Senior DevOps Engineer",
        "company": "indiagold",
        "location": "Gurugram, India",
        "url": "https://builtin.com/job/senior-devops-engineer/10819382",
        "source": "Built In (indiagold)",
        "posted_at": "2026-09-02",
        "salary": "",
        "hr_contact": "",
        "description": (
            "Own and design AWS infrastructure, production Kubernetes and Docker "
            "environments, CI/CD pipelines, infrastructure automation and monitoring. "
            "Debug distributed production issues and partner with backend engineers to "
            "improve deployment speed, safety and reliability. Terraform, Helm, "
            "Prometheus, Grafana, Python, Bash, Linux. Lending and fintech NBFC domain. "
            "3+ years experience."
        ),
    },
    {
        "title": "DevOps Engineer (Cloud Platform)",
        "company": "SarvaGram",
        "location": "Pune, India",
        "url": "https://builtin.com/job/devops-engineer/10810868",
        "source": "Built In (SarvaGram)",
        "posted_at": "2026-09-01",
        "salary": "",
        "hr_contact": "",
        "description": (
            "Own and scale AWS cloud infrastructure, CI/CD pipelines, Kubernetes "
            "platforms, monitoring, reliability, security and incident response. Build "
            "infrastructure as code with Terraform, automate deployments, manage "
            "production environments, optimize costs and implement backup and disaster "
            "recovery. Docker, Helm, Jenkins, ELK, Prometheus, Python, Bash, Linux. "
            "Rural lending NBFC fintech. 3+ years experience."
        ),
    },
    {
        "title": "DevOps Engineer (Cloud & Container Platform)",
        "company": "Marketscope",
        "location": "Mumbai, India",
        "url": "https://builtin.com/job/devops-engineer-id-1282/9847964",
        "source": "Built In (Marketscope)",
        "posted_at": "2026-08-26",
        "salary": "",
        "hr_contact": "",
        "description": (
            "Design VPC segmentation, security groups and firewall rules for network "
            "isolation. Implement zero-trust service mesh on Kubernetes. Containerize "
            "and orchestrate services on EKS. Build a unified CI/CD deployment platform "
            "for polyglot backends. Enable CDN and blue-green frontend deployments, API "
            "gateway, HA and backup strategies with RTO and RPO targets. Deploy full "
            "observability stack for metrics, logs and traces with SLO dashboards. "
            "Create runbooks, incident response and post-mortem practice. Terraform, "
            "Docker, Helm, Python. 5+ years in DevOps or SRE."
        ),
    },
    {
        "title": "Senior DevOps Engineer (Big Data Platform)",
        "company": "Mactores",
        "location": "India (Remote)",
        "url": "https://builtin.com/job/senior-devops-engineer/9164314",
        "source": "Built In (Mactores)",
        "posted_at": "2026-08-25",
        "salary": "",
        "hr_contact": "",
        "description": (
            "DevOps engineer with expertise in infrastructure as code, configuration "
            "management, continuous integration and deployment and automated monitoring "
            "for big data workloads and large enterprise applications. AWS EMR, EKS, "
            "Terraform, Jenkins, Docker, Kubernetes, Airflow, Spark, Python, Bash, "
            "Linux, Prometheus, Grafana, ELK. Data platform and analytics domain. "
            "4+ years experience."
        ),
    },
    {
        "title": "Senior DevOps & Site Reliability Engineer",
        "company": "Delphic Global",
        "location": "India (Hybrid)",
        "url": "https://builtin.com/job/sre-devops-cloud-engineer/9750514",
        "source": "Built In (Delphic Global)",
        "posted_at": "2026-09-05",
        "salary": "",
        "hr_contact": "",
        "description": (
            "Manage, automate and optimize hybrid cloud infrastructure across AWS. "
            "Blend DevOps practices with SRE principles to build resilient, scalable "
            "and highly available systems. Kubernetes, EKS, Docker, Terraform, Jenkins "
            "CI/CD, Helm, Prometheus, Grafana, ELK, Python, Bash, Linux, IAM, VPC, "
            "incident response, SLO. Some Azure exposure expected. 4+ years experience."
        ),
    },
    {
        "title": "Senior / Lead Cloud Platform Engineer",
        "company": "TechBlocks",
        "location": "India (Hybrid)",
        "url": "https://builtin.com/job/senior-lead-cloud-platform-engineer/9684779",
        "source": "Built In (TechBlocks)",
        "posted_at": "2026-08-27",
        "salary": "",
        "hr_contact": "",
        "description": (
            "Build and manage secure, scalable, policy-driven cloud infrastructure "
            "while enabling automation and governance across cloud-native platforms. "
            "AWS, Kubernetes, EKS, Terraform, Helm, Docker, CI/CD, GitOps, ArgoCD, "
            "observability, IAM, VPC, cost governance and FinOps, Python. 5+ years "
            "experience."
        ),
    },
    {
        "title": "DevOps Engineer (Industrial Digital Solutions)",
        "company": "Airbus",
        "location": "Bengaluru, India",
        "url": "https://builtin.com/job/devops-engineer-industrial-digital-solutions/10260377",
        "source": "Built In (Airbus)",
        "posted_at": "2026-08-30",
        "salary": "",
        "hr_contact": "",
        "description": (
            "4+ years in DevOps and cloud infrastructure with a minimum of 2 years "
            "focused on Jenkins and EKS pipelines. AWS, Kubernetes, Docker, Terraform, "
            "Helm, Python, Bash, Linux, Prometheus, Grafana, ELK observability, IAM and "
            "VPC networking, CI/CD automation."
        ),
    },
    {
        "title": "DevOps Engineer (AWS Data & Container Platform)",
        "company": "Insight Global (client engagement)",
        "location": "India",
        "url": "https://in.linkedin.com/jobs/view/devops-engineer-at-insight-global-4385245964",
        "source": "LinkedIn",
        "posted_at": "2026-08-25",
        "salary": "",
        "hr_contact": "",
        "description": (
            "Building and expanding a DevOps team to support and evolve a large-scale "
            "AWS-based data and container platform. EKS, Kubernetes, Docker, Terraform, "
            "Jenkins CI/CD, Airflow orchestration, EMR and Spark workloads, Helm, "
            "Prometheus, Grafana, ELK, Python, Bash, Linux, cost optimization. "
            "3+ years experience."
        ),
    },
    {
        "title": "DevOps Engineer (Mumbai, 3-8 yrs)",
        "company": "2COMS Consulting",
        "location": "Mumbai, India",
        "url": "https://builtin.com/job/devops-engineer-mumbai-3-8-yrs/10843681",
        "source": "Built In (2COMS)",
        "posted_at": "2026-09-04",
        "salary": "",
        "hr_contact": "",
        "description": (
            "Cloud and DevOps exposure across AWS, CI/CD, containers, Kubernetes, "
            "automation, observability, artifact repositories and application support "
            "tooling. Jenkins, Docker, Terraform, Helm, Prometheus, Grafana, ELK, "
            "Python, Bash, Linux. Candidates must reside in Mumbai or be willing to "
            "relocate. 3-8 years experience."
        ),
    },
    {
        "title": "Senior DevOps Engineer",
        "company": "Razorpay",
        "location": "Bengaluru, India",
        "url": "https://razorpay.com/careers/",
        "source": "Razorpay careers",
        "posted_at": "2026-08-25",
        "salary": "",
        "hr_contact": "",
        "description": (
            "Scale the payments infrastructure that powers millions of businesses. "
            "AWS, Kubernetes, EKS, Docker, Terraform, CI/CD, Helm, service mesh, "
            "observability with Prometheus and Grafana, incident response and SLO "
            "practice, Python and Go automation, Linux. Fintech and payments domain, "
            "high-scale multi-tenant platform. 4+ years experience."
        ),
    },

    # ------------------------------------------------------------------
    # CLOUD / PLATFORM SRE FAMILY
    # ------------------------------------------------------------------
    {
        "title": "Platform Engineer (SRE - India) - Senior IC",
        "company": "Amtech Software",
        "location": "India (Remote)",
        "url": "https://boards.greenhouse.io/amtechsoftware/jobs/4362897009",
        "source": "Greenhouse (Amtech)",
        "posted_at": "2026-08-28",
        "salary": "",
        "hr_contact": "",
        "description": (
            "Senior individual contributor on the SRE track. Own the reliability of "
            "significant production domains, design the observability and automation "
            "frameworks the team standardizes on, and act as incident commander for "
            "complex cross-service incidents. Multi-account AWS estate, multi-tenant "
            "SaaS. Terraform, Kubernetes, EKS, Docker, Helm, OpenTelemetry, "
            "Prometheus, Grafana, Python, Linux, SLO and error budgets, high "
            "availability, disaster recovery. 4+ years experience."
        ),
    },
    {
        "title": "Senior Site Reliability Engineer",
        "company": "Clearwater Analytics",
        "location": "India (Hybrid)",
        "url": "https://builtin.com/job/senior-site-reliability-engineer/8980772",
        "source": "Built In (Clearwater Analytics)",
        "posted_at": "2026-08-26",
        "salary": "",
        "hr_contact": "",
        "description": (
            "Own the observability platform end to end with Prometheus, Grafana and "
            "distributed tracing via OpenTelemetry. Establish SLO and SLI frameworks "
            "and track SLAs across all systems and applications. AWS, Kubernetes, "
            "Terraform, Docker, Helm, CI/CD, incident response, capacity planning, "
            "high availability, Python and Bash on Linux. Investment management and "
            "capital markets data platform. 4+ years experience."
        ),
    },
    {
        "title": "Site Reliability Engineer (AWS Observability)",
        "company": "Experian",
        "location": "Hyderabad, India",
        "url": "https://jobs.experian.com/job/site-reliability-engineer-in-hyderabad-india-jid-6010",
        "source": "Experian careers",
        "posted_at": "2026-08-31",
        "salary": "",
        "hr_contact": "",
        "description": (
            "Build and scale observability solutions across cloud-native and data "
            "engineering platforms on AWS. Use Datadog, Splunk and OpenTelemetry to "
            "implement proactive monitoring, define SLIs and SLOs and enhance service "
            "reliability. Kubernetes, EKS, Terraform, Docker, CI/CD, incident "
            "response, Python, Linux. Credit bureau and financial data domain. "
            "4+ years experience."
        ),
    },
    {
        "title": "Senior Site Reliability Engineer",
        "company": "AgileEngine",
        "location": "India (Remote)",
        "url": "https://builtin.com/job/senior-site-reliability-engineer-id81653/10748387",
        "source": "Built In (AgileEngine)",
        "posted_at": "2026-08-30",
        "salary": "",
        "hr_contact": "",
        "description": (
            "Support platform reliability, monitoring and modernization across "
            "Kubernetes-based microservices environments with a strong observability "
            "focus. AWS, EKS, Terraform, Helm, Docker, CI/CD, Prometheus, Grafana, "
            "OpenTelemetry distributed tracing, incident response, SLO, high "
            "availability, Python, Bash, Linux. 4+ years experience."
        ),
    },
    {
        "title": "Kubernetes SRE (India)",
        "company": "Insight Global",
        "location": "India (Remote)",
        "url": "https://jobs.insightglobal.com/jobs/find_a_job/minnesota/saint-paul/kubernetes-sre-intl-india/job-562750/",
        "source": "Insight Global careers",
        "posted_at": "2026-08-29",
        "salary": "",
        "hr_contact": "",
        "description": (
            "Build and tune monitoring, logging, tracing and alerting with Elastic, "
            "Prometheus, Grafana and Datadog. Operate Kubernetes clusters at scale, "
            "drive automation with Terraform, support CI/CD, incident response and "
            "reliability engineering. AWS, EKS, Docker, Helm, Python, Bash, Linux, "
            "SLO, high availability. 3+ years experience."
        ),
    },
    {
        "title": "Site Reliability Engineer - Intermediate",
        "company": "Equifax",
        "location": "Pune, India",
        "url": "https://careers.equifax.com/en/jobs/j00178309/site-reliability-engineer-intermediate/",
        "source": "Equifax careers",
        "posted_at": "2026-08-30",
        "salary": "",
        "hr_contact": "",
        "description": (
            "SRE at Equifax combines software and systems engineering to build and run "
            "large-scale, distributed, fault-tolerant systems. Kubernetes, containers, "
            "Terraform infrastructure as code, CI/CD pipelines, observability with "
            "Prometheus and Grafana, SLO and error budgets, incident response, "
            "capacity planning, Python, Bash, Linux. Credit bureau and financial "
            "services domain. 3+ years experience."
        ),
    },
    {
        "title": "Senior Service Reliability Engineer",
        "company": "Thoughtworks",
        "location": "India (Hybrid)",
        "url": "https://job-boards.greenhouse.io/thoughtworksreferral/jobs/8103055",
        "source": "Greenhouse (Thoughtworks)",
        "posted_at": "2026-08-27",
        "salary": "",
        "hr_contact": "",
        "description": (
            "Take a multifaceted approach to technical excellence and operational "
            "efficiency within the infrastructure domain. Specialize in reliability, "
            "resilience and system performance, championing Site Reliability "
            "Engineering principles. AWS, Kubernetes, Terraform, Docker, Helm, CI/CD, "
            "observability, SLO, incident response, high availability, Python, Linux. "
            "4+ years experience."
        ),
    },
    {
        "title": "Site Reliability Engineer (SRE) / DevOps Engineer",
        "company": "New Era Technology",
        "location": "India (Remote)",
        "url": "https://job-boards.greenhouse.io/neweratech/jobs/8713404002",
        "source": "Greenhouse (New Era Technology)",
        "posted_at": "2026-08-28",
        "salary": "",
        "hr_contact": "",
        "description": (
            "The role spans DevOps and SRE responsibilities including CI/CD, cloud "
            "infrastructure, observability, production reliability, incident "
            "management and operational automation. AWS, Kubernetes, Docker, "
            "Terraform, Helm, Jenkins, Prometheus, Grafana, ELK, Python, Bash, Linux, "
            "high availability. 3+ years experience."
        ),
    },
    {
        "title": "DevOps / SRE Engineer (Platform & AI Services)",
        "company": "Confidential (via ET CIO)",
        "location": "India",
        "url": "https://cio.economictimes.indiatimes.com/jobs/devops-sre-engineer/907706",
        "source": "ET CIO Jobs",
        "posted_at": "2026-08-25",
        "salary": "",
        "hr_contact": "",
        "description": (
            "Run mission-critical workloads on cloud infrastructure, harden "
            "Kubernetes-based systems and ensure high availability, performance and "
            "cost efficiency across platform and AI services. AWS, EKS, Terraform, "
            "Docker, Helm, CI/CD, observability, SLO, incident response, cost "
            "optimization, Python, Linux. 3+ years experience."
        ),
    },
    {
        "title": "Site Reliability Engineering (Cloud Platform)",
        "company": "Palo Alto Networks",
        "location": "Hyderabad, India",
        "url": "https://jobs.paloaltonetworks.com/en/job/hyderabad/site-reliability-engineering/47263/98035534384",
        "source": "Palo Alto Networks careers",
        "posted_at": "2026-08-26",
        "salary": "",
        "hr_contact": "",
        "description": (
            "Drive and improve incident management processes, collaborating with "
            "development and operations teams to maintain resilient systems. Monitor "
            "system health, maintain fault-tolerant distributed systems and optimize "
            "performance. AWS, Kubernetes, Terraform, Docker, CI/CD, observability, "
            "SLO, high availability, Python, Linux. Multi-tenant SaaS security "
            "platform. 4+ years experience."
        ),
    },

    # ------------------------------------------------------------------
    # ADDITIONAL PLATFORM / CLOUD / DEVOPS ROLES
    # ------------------------------------------------------------------
    {
        "title": "Senior Cloud Engineer (Kubernetes Platform)",
        "company": "Postman",
        "location": "Bengaluru, India",
        "url": "https://builtin.com/job/senior-cloud-engineer/7274129",
        "source": "Built In (Postman)",
        "posted_at": "2026-08-25",
        "salary": "",
        "hr_contact": "",
        "description": (
            "Cloud Engineer role focused on Kubernetes, ArgoCD, Helm and Crossplane. "
            "Build and operate the internal developer platform on AWS with GitOps "
            "workflows, Terraform infrastructure as code, EKS cluster management, "
            "autoscaling, observability with Prometheus and Grafana, CI/CD, Python and "
            "Go automation, Linux. Multi-tenant developer SaaS. 4+ years experience."
        ),
    },
    {
        "title": "Senior Cloud DevOps Engineer (Analytics & AI Platform)",
        "company": "Revmind AI Labs",
        "location": "India (Remote)",
        "url": "https://builtin.com/job/senior-cloud-devops-engineer/10812705",
        "source": "Built In (Revmind AI Labs)",
        "posted_at": "2026-09-01",
        "salary": "",
        "hr_contact": "",
        "description": (
            "Own the design, deployment and reliability of the AWS cloud platform "
            "including infrastructure automation, containerized and serverless "
            "workloads, observability and security, supporting data science, AI and "
            "enterprise product development. Cost-effective, secure and scalable "
            "platform for analytics needs. Terraform, EKS, Kubernetes, Docker, Lambda, "
            "CI/CD, Prometheus, Grafana, Python, Linux, cost optimization. "
            "4+ years experience."
        ),
    },
    {
        "title": "Senior DevOps Engineer (Platform Operations)",
        "company": "Orion Innovation",
        "location": "India (Hybrid)",
        "url": "https://builtin.com/job/senior-devops-engineer/8387418",
        "source": "Built In (Orion Innovation)",
        "posted_at": "2026-08-27",
        "salary": "",
        "hr_contact": "",
        "description": (
            "Maintain Terraform modules, enhance CI/CD pipelines and optimize "
            "Kubernetes management processes. Play a key role in incident response and "
            "service reliability, contributing to efficiency and cost-effectiveness of "
            "platform operations. AWS, EKS, Docker, Helm, Jenkins, Prometheus, "
            "Grafana, Python, Bash, Linux, SLO, cost optimization. 4+ years experience."
        ),
    },
    {
        "title": "DevOps Engineer (Data Platform, SRE principles)",
        "company": "Lingaro",
        "location": "India (Remote)",
        "url": "https://builtin.com/job/devops-engineer-contract/10945695",
        "source": "Built In (Lingaro)",
        "posted_at": "2026-09-03",
        "salary": "",
        "hr_contact": "",
        "description": (
            "Maintain and enhance the stability, availability and performance of "
            "critical applications and data infrastructure by integrating Site "
            "Reliability Engineering principles into the platform's design and "
            "operation. AWS, Kubernetes, Terraform, Docker, Airflow, CI/CD, "
            "observability, Python, Linux, high availability, incident response. "
            "Data platform and analytics domain. 4+ years experience."
        ),
    },
    {
        "title": "Mid-Level Cloud DevOps Engineer",
        "company": "Cogniify",
        "location": "India (Remote)",
        "url": "https://builtin.com/job/mid-level-cloud-dev-ops-india/9752050",
        "source": "Built In (Cogniify)",
        "posted_at": "2026-09-05",
        "salary": "",
        "hr_contact": "",
        "description": (
            "Own key infrastructure components end to end, drive CI/CD maturity, "
            "manage containerized and serverless workloads and collaborate with "
            "development and data teams to ensure reliable, secure and cost-optimized "
            "cloud operations. AWS, EKS, Kubernetes, Terraform, Docker, Helm, Lambda, "
            "Prometheus, Grafana, Python, Bash, Linux. 3+ years experience."
        ),
    },
    {
        "title": "DevOps Engineer (Enterprise CI/CD Platform)",
        "company": "Photon",
        "location": "India (Hybrid)",
        "url": "https://builtin.com/job/devops-engineer/10635755",
        "source": "Built In (Photon)",
        "posted_at": "2026-08-27",
        "salary": "",
        "hr_contact": "",
        "description": (
            "Design, implement, maintain and troubleshoot enterprise-grade CI/CD "
            "platforms and deployment pipelines supporting multiple application teams "
            "across environments. Jenkins, AWS, Kubernetes, EKS, Docker, Terraform, "
            "Helm, artifact repositories, observability, Python, Groovy, Bash, Linux. "
            "Multi-tenant internal developer platform. 4+ years experience."
        ),
    },
    {
        "title": "Infrastructure Platform Engineering (SMTS)",
        "company": "Salesforce",
        "location": "Hyderabad, India",
        "url": "https://www.salesforce.com/company/careers/jobs/JR356752/infrastructure-platform-engineering-smts-software-engineering/",
        "source": "Salesforce careers",
        "posted_at": "2026-09-01",
        "salary": "",
        "hr_contact": "",
        "description": (
            "Strong infrastructure engineer to contribute to high-impact "
            "modernization and cloud platform efforts. Kubernetes, containers, "
            "Terraform infrastructure as code, CI/CD automation, observability, "
            "reliability and high availability at very large scale, Python and Java "
            "automation, Linux. 4+ years experience."
        ),
    },
    {
        "title": "Senior Platform Software Engineer",
        "company": "Oracle",
        "location": "Bengaluru, India",
        "url": "https://careers.oracle.com/en/sites/jobsearch/job/341451/",
        "source": "Oracle careers",
        "posted_at": "2026-08-28",
        "salary": "",
        "hr_contact": "",
        "description": (
            "Strong understanding of container technology like Docker and container "
            "orchestration like Kubernetes; familiarity with managed Kubernetes "
            "services such as Amazon EKS is an added advantage. Build cloud platform "
            "services with Terraform, CI/CD, observability, high availability, Python "
            "and Java, Linux. 4+ years experience."
        ),
    },
    {
        "title": "DevOps Engineer (SaaS Build & Deployment Platform)",
        "company": "Palo Alto Networks",
        "location": "Hyderabad, India",
        "url": "https://jobs.paloaltonetworks.com/en/job/hyderabad/devops-engineer/47263/100168706544",
        "source": "Palo Alto Networks careers",
        "posted_at": "2026-09-03",
        "salary": "",
        "hr_contact": "",
        "description": (
            "Design, develop and maintain the build and deployment pipeline of our "
            "SaaS product. Jenkins CI/CD, AWS, Kubernetes, EKS, Docker, Terraform, "
            "Helm, artifact management, observability, Python, Bash, Linux, security "
            "controls. Multi-tenant SaaS platform. 4+ years experience."
        ),
    },
    {
        "title": "Senior DevOps / DevSecOps Engineer",
        "company": "Amgen",
        "location": "Hyderabad, India",
        "url": "https://careers.amgen.com/en/job/hyderabad/senior-devops-devsecops-engineer/87/87896829328",
        "source": "Amgen careers",
        "posted_at": "2026-08-30",
        "salary": "",
        "hr_contact": "",
        "description": (
            "Build and secure cloud-native platforms on AWS. CI/CD pipelines, "
            "Kubernetes and EKS, Docker, Terraform, Helm, secrets management, IAM and "
            "VPC security, observability with Prometheus and Grafana, ELK logging, "
            "Python and Bash on Linux, compliance and regulated environment. "
            "4+ years experience."
        ),
    },
    {
        "title": "DevOps Engineer (AWS Cloud Platform)",
        "company": "Ventura Securities",
        "location": "Thane, Mumbai, India",
        "url": "https://in.indeed.com/q-devops-l-mumbai,-maharashtra-jobs.html",
        "source": "Indeed (Ventura Securities)",
        "posted_at": "2026-08-29",
        "salary": "",
        "hr_contact": "",
        "description": (
            "Omnichannel trading and investment platform with branches, sub-brokers "
            "and digital channels. Good understanding of cloud performance and cost "
            "optimisation. AWS, Kubernetes, Docker, Terraform, Jenkins CI/CD, "
            "observability, Python, Bash, Linux, high availability. Capital markets "
            "and broking fintech, Mumbai-based. 3+ years experience."
        ),
    },
    {
        "title": "Senior DevOps Engineer (Cloud Platform)",
        "company": "Lloyds Technology Centre",
        "location": "Hyderabad, India",
        "url": "https://builtin.com/job/senior-devops-engineer/10098142",
        "source": "Built In (Lloyds Technology Centre)",
        "posted_at": "2026-08-25",
        "salary": "",
        "hr_contact": "",
        "description": (
            "Recommend appropriate pipelines and tools aligned to group strategy, "
            "identify and implement process and security improvements and deliver "
            "outcomes within established risk frameworks. AWS, Kubernetes, Terraform, "
            "Docker, Helm, Jenkins CI/CD, observability, Python, Linux. Banking and "
            "regulated financial services domain. 5+ years experience."
        ),
    },
    {
        "title": "AWS DevOps Engineer (Hybrid Pune)",
        "company": "Talpro India",
        "location": "Pune, India",
        "url": "https://builtin.com/job/aws-devops-engineer/10819872",
        "source": "Built In (Talpro India)",
        "posted_at": "2026-09-01",
        "salary": "",
        "hr_contact": "",
        "description": (
            "AWS cloud-native and serverless applications including Lambda, API "
            "Gateway, DynamoDB, SQS and ECS/EKS. Implement CI/CD pipelines and "
            "infrastructure as code with Terraform and CloudFormation. Kubernetes, "
            "Docker, Helm, observability, Python, Bash, Linux. Hybrid from the Pune "
            "office three days per week. 4+ years experience."
        ),
    },
    {
        "title": "DevOps / MLOps Engineer (AWS)",
        "company": "Talpro India",
        "location": "India (Hybrid)",
        "url": "https://builtin.com/job/dev-ops-mlops-engineer/10819823",
        "source": "Built In (Talpro India)",
        "posted_at": "2026-09-02",
        "salary": "",
        "hr_contact": "",
        "description": (
            "Build and manage AWS cloud-native and serverless applications including "
            "Lambda, API Gateway, DynamoDB, SQS and ECS/EKS. Implement CI/CD pipelines "
            "and infrastructure as code using Terraform and CloudFormation. Support "
            "AI/ML workloads, model deployment, monitoring and lifecycle management. "
            "SageMaker, Kubernetes, Docker, Airflow, Python, Linux. 4+ years."
        ),
    },
    {
        "title": "Senior DevOps Engineer (Trading Platform)",
        "company": "Kuru Labs",
        "location": "India (Remote)",
        "url": "https://builtin.com/job/senior-devops-engineer/10573983",
        "source": "Built In (Kuru Labs)",
        "posted_at": "2026-08-29",
        "salary": "",
        "hr_contact": "",
        "description": (
            "Build and maintain CI/CD pipelines and GitOps deployments for a "
            "high-availability containerized exchange stack. Prototype deployment "
            "patterns, run performance and load tests, drive observability and "
            "security, develop tooling and participate in on-call production support. "
            "AWS, Kubernetes, Terraform, Docker, Helm, ArgoCD, Prometheus, Grafana, "
            "Python, Linux. Trading and capital markets. 4+ years experience."
        ),
    },
    {
        "title": "AWS Cloud Engineer (EKS & AI Platform)",
        "company": "Adastra",
        "location": "India (Remote)",
        "url": "https://careersgdc.adastracorp.com/aws-cloud-engineer-eks-ai-platform/",
        "source": "Adastra careers",
        "posted_at": "2026-08-31",
        "salary": "",
        "hr_contact": "",
        "description": (
            "Design, build and operate a scalable Kubernetes-native platform powering "
            "AI agent orchestration. AWS, EKS, Terraform, Helm, Docker, autoscaling "
            "with Karpenter, GitOps, CI/CD, observability with Prometheus and Grafana, "
            "OpenTelemetry, Python, Linux, cost optimization. 4+ years experience."
        ),
    },
    {
        "title": "Cloud DevOps Engineer (Data Pipelines)",
        "company": "Bosch Group",
        "location": "Pune, India",
        "url": "https://in.indeed.com/q-aws-devops-l-kalyani-nagar,-pune,-maharashtra-jobs.html",
        "source": "Indeed (Bosch Group)",
        "posted_at": "2026-08-28",
        "salary": "",
        "hr_contact": "",
        "description": (
            "Ensure the stability, scalability and performance of the data pipelines "
            "solution. Monitor and maintain batch data pipelines in a cloud-based "
            "environment. AWS, Kubernetes, Docker, Terraform, Airflow, Spark, CI/CD, "
            "observability, Python, Bash, Linux, high availability. Data platform and "
            "analytics domain. 4+ years experience."
        ),
    },
    {
        "title": "DevOps Engineer (AWS & Kubernetes)",
        "company": "Wolters Kluwer",
        "location": "Pune, India",
        "url": "https://in.indeed.com/q-aws-devops-l-pune,-maharashtra-jobs.html",
        "source": "Indeed (Wolters Kluwer)",
        "posted_at": "2026-08-27",
        "salary": "",
        "hr_contact": "",
        "description": (
            "Perform technology tasks with increasing independence across AWS, Docker "
            "and Kubernetes. CI/CD pipelines, Terraform infrastructure as code, Helm, "
            "observability with Prometheus and Grafana, ELK logging, Python and Bash "
            "on Linux, high availability. Regulated information services SaaS. "
            "4+ years experience."
        ),
    },
    {
        "title": "Senior DevOps Engineer (Cloud Platform)",
        "company": "McKesson",
        "location": "Bengaluru, India",
        "url": "http://careers.mckesson.com/en/job/bengaluru/senior-devops-engineer/733/96913298224",
        "source": "McKesson careers",
        "posted_at": "2026-08-26",
        "salary": "",
        "hr_contact": "",
        "description": (
            "Use problem-solving skills to push the boundaries of innovation in "
            "healthcare technology. AWS, Kubernetes, EKS, Docker, Terraform, Helm, "
            "Jenkins CI/CD, observability with Prometheus and Grafana, ELK, incident "
            "response, Python, Bash, Linux, compliance and regulated environment. "
            "4+ years experience."
        ),
    },
    {
        "title": "DevOps Engineer (AWS Cloud & Backend Platform)",
        "company": "Route Mobile",
        "location": "Mumbai, India",
        "url": "https://in.indeed.com/q-aws-cloud-engineer-l-mumbai,-maharashtra-jobs.html",
        "source": "Indeed (Route Mobile)",
        "posted_at": "2026-08-29",
        "salary": "",
        "hr_contact": "",
        "description": (
            "4+ years of experience as a DevOps and cloud engineer with AWS. Serving "
            "enterprises, OTT players and mobile network operators at high message "
            "volumes. Kubernetes, EKS, Docker, Terraform, Jenkins CI/CD, Helm, "
            "observability with Prometheus and Grafana, ELK, Python, Bash, Linux, high "
            "availability, cost optimization. Mumbai-based CPaaS platform."
        ),
    },
    {
        "title": "DevOps Engineer (Cloud Infrastructure)",
        "company": "Investec",
        "location": "Mumbai, India",
        "url": "https://in.indeed.com/q-devops-engineer-,-devsecops-engineer-l-mumbai,-maharashtra-jobs.html",
        "source": "Indeed (Investec)",
        "posted_at": "2026-08-28",
        "salary": "",
        "hr_contact": "",
        "description": (
            "International bank and wealth manager. Build and operate cloud "
            "infrastructure and CI/CD pipelines. AWS, Kubernetes, Docker, Terraform, "
            "Jenkins, Helm, observability, ELK, Python, Bash, Linux, IAM and VPC "
            "security, high availability, regulated banking and compliance. "
            "Mumbai-based. 3+ years experience."
        ),
    },
    {
        "title": "Senior DevOps Engineer (Platform Reliability)",
        "company": "Spring Financial",
        "location": "India (Remote)",
        "url": "https://builtin.com/job/senior-devops-engineer-6-month-contract/8385503",
        "source": "Built In (Spring Financial)",
        "posted_at": "2026-08-26",
        "salary": "",
        "hr_contact": "",
        "description": (
            "Lead targeted infrastructure initiatives, redesign and optimize CI/CD "
            "workflows and strengthen observability, cost efficiency and deployment "
            "automation. Hands-on work with engineering, platform and security teams to "
            "reduce operational risk and support scalable growth. AWS, Kubernetes, "
            "Terraform, Docker, Helm, Prometheus, Grafana, Python, Linux. Lending "
            "fintech. 4+ years experience."
        ),
    },
    {
        "title": "AWS DevOps / Cloud Infrastructure Engineer",
        "company": "Tiqo Technologies",
        "location": "Hyderabad, India",
        "url": "https://in.indeed.com/q-cloud-infrastructure-engineer-jobs.html",
        "source": "Indeed (Tiqo Technologies)",
        "posted_at": "2026-08-30",
        "salary": "",
        "hr_contact": "",
        "description": (
            "Document the infrastructure clearly enough for another engineer to "
            "operate it. Configure Redis or equivalent caching and queue "
            "infrastructure. AWS, Kubernetes, EKS, Docker, Terraform, CI/CD, "
            "observability, Python, Bash, Linux, high availability, cost optimization. "
            "3-5 years of experience in cloud infrastructure, systems engineering or "
            "platform engineering."
        ),
    },
    {
        "title": "AWS Cloud Engineer (Infrastructure Automation)",
        "company": "Relevance Labs",
        "location": "India (Remote)",
        "url": "https://in.indeed.com/q-cloud-infrastructure-engineer-jobs.html",
        "source": "Indeed (Relevance Labs)",
        "posted_at": "2026-08-29",
        "salary": "",
        "hr_contact": "",
        "description": (
            "Design, implement and manage robust, scalable and secure cloud "
            "infrastructure on Amazon Web Services. Terraform infrastructure as code, "
            "Kubernetes and EKS, Docker, Helm, CI/CD pipelines, IAM and VPC, "
            "observability with Prometheus and Grafana, Python, Bash, Linux, cost "
            "optimization. 4+ years experience."
        ),
    },
    {
        "title": "DevOps Engineer (AWS, Docker, Jenkins)",
        "company": "Focalworks Solutions",
        "location": "Navi Mumbai, India",
        "url": "https://in.indeed.com/q-devops-engineer,aws-l-mumbai,-maharashtra-jobs.html",
        "source": "Indeed (Focalworks Solutions)",
        "posted_at": "2026-08-28",
        "salary": "",
        "hr_contact": "",
        "description": (
            "Build centralized log collection using Loki, ELK or OpenSearch. AWS, "
            "Docker, Jenkins CI/CD, Kubernetes, Terraform, Helm, observability with "
            "Prometheus and Grafana, Python, Bash, Linux, high availability. "
            "Navi Mumbai based. 3+ years experience."
        ),
    },
    {
        "title": "Senior DevOps Engineer (AWS Platform)",
        "company": "Whitewhale Software Solutions",
        "location": "Mumbai, India",
        "url": "https://in.indeed.com/q-devops,-sre-l-mumbai,-maharashtra-jobs.html",
        "source": "Indeed (Whitewhale Software)",
        "posted_at": "2026-08-27",
        "salary": "",
        "hr_contact": "",
        "description": (
            "4-5 years of experience in a DevOps or related role. AWS, Kubernetes, "
            "Docker, Terraform, Jenkins CI/CD, Helm, observability with Prometheus and "
            "Grafana, ELK logging, Python, Bash, Linux, IAM and VPC, high "
            "availability, cost optimization. Mumbai-based."
        ),
    },
    {
        "title": "DevOps Engineer (Cloud Automation)",
        "company": "Toadster Technologies",
        "location": "Mumbai, India",
        "url": "https://in.indeed.com/q-devops,-sre-l-mumbai,-maharashtra-jobs.html",
        "source": "Indeed (Toadster Technologies)",
        "posted_at": "2026-08-29",
        "salary": "",
        "hr_contact": "",
        "description": (
            "Automate operational workflows in line with security and reliability "
            "standards. Gather cloud infrastructure requirements and propose scalable "
            "solutions. AWS, Kubernetes, Docker, Terraform, CI/CD, observability, "
            "Python, Bash, Linux, high availability. Mumbai-based. 3+ years experience."
        ),
    },
    {
        "title": "Senior DevOps Engineer (Deployment Safety)",
        "company": "Trilogy",
        "location": "Mumbai / Remote, India",
        "url": "https://www.crossover.com/jobs/ai-developer/india/mh/mumbai/c-a0q2j0000097ldSAAQ/trilogy-senior-devops-engineer",
        "source": "Crossover (Trilogy)",
        "posted_at": "2026-08-26",
        "salary": "",
        "hr_contact": "",
        "description": (
            "Write the deployment playbooks and design rollouts from dev to staged to "
            "10 percent to 100 percent with soak and rollback triggers, and build the "
            "monitors that catch edge cases. Reject unsafe changes before release. "
            "AWS, Kubernetes, Terraform, Docker, CI/CD, canary and blue-green "
            "deployment, observability, SLO, incident response, runbooks, Python, "
            "Linux. 4+ years experience."
        ),
    },
    {
        "title": "Cloud DevOps Engineer SME",
        "company": "Tech Mahindra",
        "location": "India (Hybrid)",
        "url": "https://careers.techmahindra.com/",
        "source": "Tech Mahindra careers",
        "posted_at": "2026-08-25",
        "salary": "",
        "hr_contact": "",
        "description": (
            "Experienced senior engineer with 5+ years who is strong across DevOps and "
            "Cloud with a genuine understanding of data engineering principles. AWS, "
            "Kubernetes, EKS, Terraform, Docker, Jenkins CI/CD, Airflow, Spark, EMR, "
            "observability, Python, Bash, Linux, cost optimization. Data platform "
            "domain."
        ),
    },
]
